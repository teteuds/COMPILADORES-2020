package controlador;

import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.*;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import analisadorSintatico.AnalisadorSintatico;

public class Controlador implements Initializable {
	@FXML public TextField inputDados;
	@FXML public Button btnDados;
	@FXML public TextArea txtResultado;	

	public AnalisadorSintatico analisadorSint = new AnalisadorSintatico();

	@Override
  public void initialize(URL url, ResourceBundle rb) {
  	analisadorSint.setControlador(this);
  }//fim metodo initialize

  public void iniciaVariaveis(){
  	txtResultado.setText("");
		analisadorSint.iniciaVariaveis();
	}//fim metodo iniciaVariaveis

}//fim classe controlador