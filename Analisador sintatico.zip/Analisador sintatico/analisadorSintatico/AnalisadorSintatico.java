package analisadorSintatico;

import controlador.Controlador;
import java.util.ArrayList; 
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.io.*;
import pilha.Pilha;

public class AnalisadorSintatico{
  Controlador c;
  String dados;
  String programa;
  FileReader arq;
  BufferedReader lerArq;
  String linha; // lê a primeira linha
  Pilha pilhaToken = new Pilha();
  Pilha pilhaEstado = new Pilha();
  String token = "";
  String tipo  = "";
  Boolean inicio = true;


  //inicia as variaveis responsaveis pela leitura do documento e chama o metodo tabelaSimbolos
  public void iniciaVariaveis(){
    try {
      String dados2 = c.inputDados.getText();
      String programa2 = "";
      FileReader arq2 = new FileReader(dados2);
      BufferedReader lerArq2 = new BufferedReader(arq2);
      //String linha2 = lerArq2.readLine(); // lê a primeira linha

      dados = dados2;
      programa = programa2;
      arq = arq2;
      lerArq = lerArq2;
      linha = "abc";
    }catch (IOException e) {
        System.err.printf("Erro na abertura do arquivo: %s.\n",
          e.getMessage());
    }

    tabelaSimbolos();
  }

  //inicia a leitura do documento que eh a tabela de simbolos e a partir disso chama o metodo pegaToken
  public void tabelaSimbolos(){
    try {
      // a variável "linha" recebe o valor "null" quando o processo
      // de repetição atingir o final do arquivo texto
      linha = lerArq.readLine(); // lê a proxima linha
      if (linha != null) {
        pegaToken(linha);
        
        //verifica se eh o inicio do programa, caso seja ele chama o primeiro estado que eh o 0.
        if(inicio){
          inicio = false;
          estado0();
        }//fim if
      
      }else{
        System.out.println("FIM DO PROGRAMA!");
        pegaToken("<  $ , palavra_reservada  >");
      }//fim else

    } catch (IOException e) {
        System.err.printf("Erro na abertura do arquivo: %s.\n",
          e.getMessage());
    }
    programa = programa.replace("null","");
    System.out.println(programa);
  }//fim metodo tabelaSimbolos

  //Metodo responsavel por separar o lexema e o token
  public void pegaToken(String tok){
    System.out.println("VALOR DO TOKEN: " + tok);
    String[] textoSeparado = tok.split(" ");
    token = textoSeparado[2];
    tipo  = textoSeparado[4];
    
    if(tipo.equals("BOOLEAN") || tipo.equals("string")){
      tipo = "identificador";
    }

    if(tipo.equals("FIM")){
      tabelaSimbolos();
    }

    //System.out.println("tamanho: " + textoSeparado.length);

    /*if(textoSeparado.length > 7){
      System.out.println("Erro lexico: " + tok);
      c.txtResultado.setText("Erro lexico: " + tok);
    }//fim if*/

  }//fim metodo pegatoken

  public void estado0(){
    System.out.println("estado 0");
    if(token.equals("PROGRAM")){
        pilhaToken.push("PROGRAM");
        String x1 = pilhaToken.top();
        pilhaEstado.push("2");
        //String x2 = pilhaEstado.top();
        System.out.println("valor de x1: " + x1);
        //System.out.println("valor de x2: " + x2);
        tabelaSimbolos();
        estado2();
    }else if((pilhaToken.top()).equals("S")){
      pilhaEstado.push("1");
      estado1();
    }else{
      System.out.println("Syntax error: 0");
    }
  }//fim metodo estado0

  public void estado1(){
    System.out.println("estado 1");
    if(token.equals("$")){
      System.out.println("PROGRAMA ACEITO!");
      c.txtResultado.setText("PROGRAMA ACEITO!");
      inicio = true;
      pilhaToken = new Pilha();
      pilhaEstado = new Pilha();
    }else{
      System.out.println("Syntax error: 1");
    }
  }//fim metodo estado1

  public void estado2(){
    System.out.println("estado 2");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("3");
      tabelaSimbolos();
      estado3();
    }else{
      System.out.println("Syntax error: 2");
    }
  }//fim metodo estado2

  public void estado3(){
    System.out.println("estado 3");
    if(token.equals(";")){
      pilhaToken.push(";");
      pilhaEstado.push("4");
      tabelaSimbolos();
      estado4();
    }else{
      System.out.println("Syntax error: 3");
    }
  }//fim metodo estado3

  public void estado4(){
    System.out.println("estado 4");
    if((pilhaToken.top()).equals("D")){
      pilhaEstado.push("5");
      estado5();
    }else if(token.equals("BEGIN")){
      reduz(3);
      estado4Esp();
    }else if(token.equals("VAR")){
      pilhaToken.push("VAR");
      pilhaEstado.push("6");
      tabelaSimbolos();
      estado6();
    }else{
      System.out.println("valor do est4: " + token);
      System.out.println("Syntax error: 4");
    }
  }//fim metodo estado4

  public void estado4Esp(){
    System.out.println("estado 4 esp");
    if((pilhaToken.top()).equals("D")){
      pilhaEstado.push("5");
      estado5();
    }
    else{
      System.out.println("Syntax error: 4");
    }
  }//fim metodo estado4Esp

  public void estado5(){
    System.out.println("estado 5");
    if(token.equals("BEGIN")){
      pilhaToken.push("BEGIN");
      pilhaEstado.push("7");
      tabelaSimbolos();
      estado7();
    }else{
      System.out.println("Syntax error: 5");
    }
  }//fim metodo estado5

  public void estado6(){
    System.out.println("estado 6");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("10");
      tabelaSimbolos();
      estado10();
    }else if((pilhaToken.top()).equals("V")){
      pilhaEstado.push("8");
      estado8();
    }else if((pilhaToken.top()).equals("I")){
      pilhaEstado.push("9");
      estado9();
    }else{
      System.out.println("Syntax error: 6");
    }
  }//fim metodo estado6

  public void estado7(){
    System.out.println("estado 7");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("19");
      tabelaSimbolos();
      estado19();
    }else if(token.equals("BEGIN")){
      pilhaToken.push("BEGIN");
      pilhaEstado.push("24");
      tabelaSimbolos();
      estado24();
    }else if(token.equals("READ")){
      pilhaToken.push("READ");
      pilhaEstado.push("20");
      tabelaSimbolos();
      estado20();
    }else if(token.equals("READLN")){
      pilhaToken.push("READLN");
      pilhaEstado.push("21");
      tabelaSimbolos();
      estado21();
    }else if(token.equals("WRITE")){
      pilhaToken.push("WRITE");
      pilhaEstado.push("22");
      tabelaSimbolos();
      estado22();
    }else if(token.equals("WRITELN")){
      pilhaToken.push("WRITELN");
      pilhaEstado.push("23");
      tabelaSimbolos();
      estado23();
    }else if(token.equals("IF")){
      pilhaToken.push("IF");
      pilhaEstado.push("25");
      tabelaSimbolos();
      estado25();
    }else if(token.equals("WHILE")){
      pilhaToken.push("WHILE");
      pilhaEstado.push("26");
      tabelaSimbolos();
      estado26();
    }else if((pilhaToken.top()).equals("L")){
      pilhaEstado.push("11");
      estado11();
    }else if((pilhaToken.top()).equals("C")){
      pilhaEstado.push("12");
      estado12();
    }else if((pilhaToken.top()).equals("A")){
      pilhaEstado.push("13");
      estado13();
    }else if((pilhaToken.top()).equals("R")){
      pilhaEstado.push("14");
      estado14();
    }else if((pilhaToken.top()).equals("W")){
      pilhaEstado.push("15");
      estado15();
    }else if((pilhaToken.top()).equals("M")){
      pilhaEstado.push("16");
      estado16();
    }else if((pilhaToken.top()).equals("N")){
      pilhaEstado.push("17");
      estado17();
    }else if((pilhaToken.top()).equals("P")){
      pilhaEstado.push("18");
      estado18();
    }
    else{
      System.out.println("Syntax error: 7");
    }//fim else
  }//fim metodo estado7

  public void estado8(){
    System.out.println("estado 8");
    if(token.equals("BEGIN")){
      reduz(2);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 8");
    }//fim else
  }//fim metodo estado8

  public void estado9(){
    System.out.println("estado 9");
    if(token.equals(":")){
      pilhaToken.push(":");
      pilhaEstado.push("27");
      tabelaSimbolos();
      estado27();
    }else{
      System.out.println("Syntax error: 9");
    }//fim else
  }//fim metodo estado9

  public void estado10(){
    System.out.println("estado 10");
    if((pilhaToken.top()).equals("I'")){
      pilhaEstado.push("28");
      estado28();
    }else if(token.equals(":")){
      //pilhaEstado.pop(); //parte do reduz
      //int est = Integer.parseInt(pilhaEstado.top());
      reduz(11);
      estado10Esp();
      //chamaEstado(est);
    }else if(token.equals(",")){
      pilhaToken.push(",");
      pilhaEstado.push("29");
      tabelaSimbolos();
      estado29();
    }else if(token.equals(")")){
      reduz(11);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 10");
    }//fim else
  }//fim metodo estado10

  public void estado10Esp(){
    System.out.println("estado 10 esp");
    if((pilhaToken.top()).equals("I'")){
      pilhaEstado.push("28");
      estado28();
    }
    else{
      System.out.println("Syntax error: 10");
    }//fim else
  }//fim metodo estado10Esp

  public void estado11(){
    System.out.println("estado 11");
    if(token.equals("END")){
      pilhaToken.push("END");
      pilhaEstado.push("30");
      tabelaSimbolos();
      estado30();
    }else{
      System.out.println("Syntax error: 11");
    }//fim else
  }//fim metodo estado11

  public void estado12(){
    System.out.println("estado 12");
    if(token.equals(";")){
      pilhaToken.push(";");
      pilhaEstado.push("31");
      tabelaSimbolos();
      estado31();
    }else{
      System.out.println("Syntax error: 12");
    }//fim else
  }//fim metodo estado12

  public void estado13(){
    System.out.println("estado 13");
    if(token.equals(";")){
      reduz(15);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(15);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 13");
    }//fim else
  }//fim metodo estado13

  public void estado14(){
    System.out.println("estado 14");
    if(token.equals(";")){
      reduz(16);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(16);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 14");
    }//fim else
  }//fim metodo estado14

  public void estado15(){
    System.out.println("estado 15");
    if(token.equals(";")){
      reduz(17);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(17);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 15");
    }//fim else
  }//fim metodo estado15

  public void estado16(){
    System.out.println("estado 16");
    if(token.equals(";")){
      reduz(18);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(18);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 16");
    }//fim else
  }//fim metodo estado16

  public void estado17(){
    System.out.println("estado 17");
    if(token.equals(";")){
      reduz(19);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(19);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 17");
    }//fim else
  }//fim metodo estado17

  public void estado18(){
    System.out.println("estado 18");
    if(token.equals(";")){
      reduz(20);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(20);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 18");
    }//fim else
  }//fim metodo estado18

  public void estado19(){
    System.out.println("estado 19");
    if(token.equals(":=")){
      pilhaToken.push(":=");
      pilhaEstado.push("32");
      tabelaSimbolos();
      estado32();
    }else{
      System.out.println("Syntax error: 19");
    }//fim else
  }//fim metodo estado19

  public void estado20(){
    System.out.println("estado 20");
    if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("33");
      tabelaSimbolos();
      estado33();
    }else{
      System.out.println("Syntax error: 20");
    }//fim else
  }//fim metodo estado20

  public void estado21(){
    System.out.println("estado 21");
    if(token.equals(";")){
      reduz(25);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("35");
      tabelaSimbolos();
      estado35();
    }else if(token.equals("ELSE")){
      reduz(25);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if((pilhaToken.top()).equals("R'")){
      pilhaEstado.push("34");
      estado34();
    }
    else{
      System.out.println("Syntax error: 21");
    }//fim else
  }//fim metodo estado 21

  public void estado22(){
    System.out.println("estado 22");
    if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("36");
      tabelaSimbolos();
      estado36();
    }else{
      System.out.println("Syntax error: 22");
    }//fim else
  }//fim metodo estado22

  public void estado23(){
    System.out.println("estado 23");
    if((pilhaToken.top()).equals("W'")){
      pilhaEstado.push("37");
      estado37();
    }else if(token.equals(";")){
      reduz(29);
      estado23Esp();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("38");
      tabelaSimbolos();
      estado38();
    }else if(token.equals("ELSE")){
      reduz(29);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 23");
    }//fim else
  }//fim metodo estado23

  public void estado23Esp(){
    System.out.println("estado 23Esp");
    if((pilhaToken.top()).equals("W'")){
      pilhaEstado.push("37");
      estado37();
    }
    else{
      System.out.println("Syntax error: 23");
    }//fim else
  }//fim metodo estado23Esp

  public void estado24(){
    System.out.println("estado 24");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("19");
      tabelaSimbolos();
      estado19();
    }else if(token.equals("BEGIN")){
      pilhaToken.push("BEGIN");
      pilhaEstado.push("24");
      tabelaSimbolos();
      estado24();
    }else if(token.equals("READ")){
      pilhaToken.push("READ");
      pilhaEstado.push("20");
      tabelaSimbolos();
      estado20();
    }else if(token.equals("READLN")){
      pilhaToken.push("READLN");
      pilhaEstado.push("21");
      tabelaSimbolos();
      estado21();
    }else if(token.equals("WRITE")){
      pilhaToken.push("WRITE");
      pilhaEstado.push("22");
      tabelaSimbolos();
      estado22();
    }else if(token.equals("WRITELN")){
      pilhaToken.push("WRITELN");
      pilhaEstado.push("23");
      tabelaSimbolos();
      estado23();
    }else if(token.equals("IF")){
      pilhaToken.push("IF");
      pilhaEstado.push("25");
      tabelaSimbolos();
      estado25();
    }else if(token.equals("WHILE")){
      pilhaToken.push("WHILE");
      pilhaEstado.push("26");
      tabelaSimbolos();
      estado26();
    }else if((pilhaToken.top()).equals("L")){
      pilhaEstado.push("39");
      estado39();
    }else if((pilhaToken.top()).equals("C")){
      pilhaEstado.push("12");
      estado12();
    }else if((pilhaToken.top()).equals("A")){
      pilhaEstado.push("13");
      estado13();
    }else if((pilhaToken.top()).equals("R")){
      pilhaEstado.push("14");
      estado14();
    }else if((pilhaToken.top()).equals("W")){
      pilhaEstado.push("15");
      estado15();
    }else if((pilhaToken.top()).equals("M")){
      pilhaEstado.push("16");
      estado16();
    }else if((pilhaToken.top()).equals("N")){
      pilhaEstado.push("17");
      estado17();
    }else if((pilhaToken.top()).equals("P")){
      pilhaEstado.push("18");
      estado18();
    }
    else{
      System.out.println("Syntax error: 24");
    }//fim else
  }//fim metodo estado24

  public void estado25(){
    System.out.println("estado 25");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("41");
      tabelaSimbolos();
      estado41();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("42");
      estado42();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }else if((pilhaToken.top()).equals("B")){
      pilhaEstado.push("40");
      estado40();
    }
    else{
      System.out.println("Syntax error: 25");
    }//fim else
  }//fim metodo estado25

  public void estado26(){
    System.out.println("estado 26");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("41");
      tabelaSimbolos();
      estado41();
    }else if(tipo.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(tipo.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("42");
      estado42();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }else if((pilhaToken.top()).equals("B")){
      pilhaEstado.push("47");
      estado47();
    }
    else{
      System.out.println("Syntax error: 26");
    }//fim else
  }//fim metodo estado26

  public void estado27(){
    System.out.println("estado 27");
    if(tipo.equals("INTEGER")){
      pilhaToken.push("INTEGER");
      pilhaEstado.push("49");
      tabelaSimbolos();
      estado49();
    }else if(tipo.equals("identificador")){
      pilhaToken.push("BOOLEAN");
      pilhaEstado.push("50");
      tabelaSimbolos();
      estado50();
    }else if((pilhaToken.top()).equals("T")){
      pilhaEstado.push("48");
      estado48();
    }
    else{
      System.out.println("token 27: " + token);
      System.out.println("Syntax error: 27");
    }//fim else
  }//fim metodo estado27

  public void estado28(){
    System.out.println("estado 28");
    if(token.equals(":")){
      reduz(9);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(9);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 28");
    }//fim else
  }//fim metodo estado28

  public void estado29(){
    System.out.println("estado 29");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("10");
      tabelaSimbolos();
      estado10();
    }else if((pilhaToken.top()).equals("I")){
      pilhaEstado.push("51");
      estado51();
    }
    else{
      System.out.println("Syntax error: 29");
    }//fim else
  }//fim metodo estado29

  public void estado30(){
    System.out.println("estado 30");
    if(token.equals("$")){
      reduz(1);
      estado0();
    }else{
      System.out.println("Syntax error: 30");
    }//fim else
  }//fim metodo estado30

  public void estado31(){
    System.out.println("estado 31");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("19");
      tabelaSimbolos();
      estado19();
    }else if(token.equals("begin")){
      pilhaToken.push("begin");
      pilhaEstado.push("24");
      tabelaSimbolos();
      estado24();
    }else if((pilhaToken.top()).equals("L'")){
      pilhaEstado.push("52");
      estado52();
    }else if(token.equals("END")){
      reduz(14);
      estado31Esp();
    }else if(token.equals("READ")){
      pilhaToken.push("READ");
      pilhaEstado.push("20");
      tabelaSimbolos();
      estado20();
    }else if(token.equals("READLN")){
      pilhaToken.push("READLN");
      pilhaEstado.push("21");
      tabelaSimbolos();
      estado21();
    }else if(token.equals("WRITE")){
      pilhaToken.push("WRITE");
      pilhaEstado.push("22");
      tabelaSimbolos();
      estado22();
    }else if(token.equals("WRITELN")){
      pilhaToken.push("WRITELN");
      pilhaEstado.push("23");
      tabelaSimbolos();
      estado23();
    }else if(token.equals("IF")){
      pilhaToken.push("IF");
      pilhaEstado.push("25");
      tabelaSimbolos();
      estado25();
    }else if(token.equals("WHILE")){
      pilhaToken.push("WHILE");
      pilhaEstado.push("26");
      tabelaSimbolos();
      estado26();
    }else if((pilhaToken.top()).equals("C")){
      pilhaEstado.push("53");
      estado53();
    }else if((pilhaToken.top()).equals("A")){
      pilhaEstado.push("13");
      estado13();
    }else if((pilhaToken.top()).equals("R")){
      pilhaEstado.push("14");
      estado14();
    }else if((pilhaToken.top()).equals("W")){
      pilhaEstado.push("15");
      estado15();
    }else if((pilhaToken.top()).equals("M")){
      pilhaEstado.push("16");
      estado16();
    }else if((pilhaToken.top()).equals("N")){
      pilhaEstado.push("17");
      estado17();
    }else if((pilhaToken.top()).equals("P")){
      pilhaEstado.push("18");
      estado18();
    }
    else{
      System.out.println("Syntax error: 31");
    }//fim else
  }//fim metodo estado31

  public void estado31Esp(){
    System.out.println("estado 31esp");
   if((pilhaToken.top()).equals("L'")){
      pilhaEstado.push("52");
      estado52();
    } else{
      System.out.println("Syntax error: 31");
    }//fim else
  }//fim metodo estado31Esp

  public void estado32(){
    System.out.println("estado 32");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(tipo.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(tipo.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("54");
      estado54();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }
    else{
      System.out.println("Syntax error: 32");
    }//fim else
  }//fim metodo estado32

  public void estado33(){
    System.out.println("estado 33");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("10");
      tabelaSimbolos();
      estado10();
    }else if((pilhaToken.top()).equals("I")){
      pilhaEstado.push("56");
      estado56();
    }
    else{
      System.out.println("Syntax error: 33");
    }//fim else
  }//fim metodo estado33

  public void estado34(){
    System.out.println("estado 34");
    if(token.equals(";")){
      reduz(23);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(23);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 34");
    }//fim else
  }//fim metodo estado34

  public void estado35(){
    System.out.println("estado 35");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("10");
      tabelaSimbolos();
      estado10();
    }else if((pilhaToken.top()).equals("I")){
      pilhaEstado.push("57");
      estado57();
    }
    else{
      System.out.println("Syntax error: 35");
    }//fim else
  }//fim metodo estado35

  public void estado36(){
    System.out.println("estado 36");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(tipo.equals("identificador")){
      pilhaToken.push("string");
      pilhaEstado.push("60");
      tabelaSimbolos();
      estado60();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("F")){
      pilhaEstado.push("58");
      estado58();
    }else if((pilhaToken.top()).equals("G")){
      pilhaEstado.push("59");
      estado59();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("61");
      estado61();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }
    else{
      System.out.println("Syntax error: 36");
    }//fim else
  }//fim metodo estado36

  public void estado37(){
    System.out.println("estado 37");
    if(token.equals(";")){
      reduz(27);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(27);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 37");
    }//fim else
  }//fim metodo estado37

  public void estado38(){
    System.out.println("estado 38");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(tipo.equals("identificador")){
      pilhaToken.push("string");
      pilhaEstado.push("60");
      tabelaSimbolos();
      estado60();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("F")){
      pilhaEstado.push("62");
      estado62();
    }else if((pilhaToken.top()).equals("G")){
      pilhaEstado.push("59");
      estado59();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("61");
      estado61();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }
    else{
      System.out.println("Syntax error: 38");
    }//fim else
  }//fim metodo estado38

  public void estado39(){
    System.out.println("estado 39");
    if(token.equals("end")){
      pilhaToken.push("end");
      pilhaEstado.push("63");
      tabelaSimbolos();
      estado63();
    }else{
      System.out.println("Syntax error: 38");
    }//fim else
  }//fim metodo estado39

  public void estado40(){
    System.out.println("estado 40");
    if(token.equals("THEN")){
      pilhaToken.push("THEN");
      pilhaEstado.push("64");
      tabelaSimbolos();
      estado64();
    }else{
      System.out.println("Syntax error: 40");
    }//fim else
  }//fim metodo estado40

  public void estado41(){
    System.out.println("estado 41");
    if((pilhaToken.top()).equals("E'")){
      pilhaEstado.push("65");
      estado65();
    }else if(token.equals(";")){
      reduz(47);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(",")){
      reduz(47);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(47);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("then")){
      reduz(50);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(47);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("do")){
      reduz(50);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("67");
      tabelaSimbolos();
      estado67();
    }else if(token.equals("+")){
      pilhaToken.push("+");
      pilhaEstado.push("66");
      tabelaSimbolos();
      estado66();
    }else if(token.equals("*")){
      pilhaToken.push("*");
      pilhaEstado.push("68");
      tabelaSimbolos();
      estado68();
    }else if(token.equals("/")){
      pilhaToken.push("/");
      pilhaEstado.push("69");
      tabelaSimbolos();
      estado69();
    }else if(token.equals("<")){
      reduz(47);
      estado41Esp();
    }else if(token.equals("<=")){
      reduz(47);
      estado41Esp();
    }else if(token.equals(">")){
      reduz(47);
      estado41Esp();
    }else if(token.equals(">=")){
      reduz(47);
      estado41Esp();
    }else if(token.equals("=")){
      reduz(47);
      estado41Esp();
    }else if(token.equals("<>")){
      reduz(47);
      estado41Esp();
    }else{
      System.out.println("Syntax error: 41");
    }//fim else
  }//fim metodo estado41


  public void estado41Esp(){
    System.out.println("estado 41esp");
    if((pilhaToken.top()).equals("E'")){
      pilhaEstado.push("65");
      estado65();
    }
    else{
      System.out.println("Syntax error: 41");
    }//fim else
  }//fim metodo estado41Esp


  public void estado42(){
    System.out.println("estado 42");
    if(token.equals("<")){
      pilhaToken.push("<");
      pilhaEstado.push("71");
      tabelaSimbolos();
      estado71();
    }else if(token.equals("<=")){
      pilhaToken.push("<=");
      pilhaEstado.push("72");
      tabelaSimbolos();
      estado72();
    }else if(token.equals(">")){
      pilhaToken.push(">");
      pilhaEstado.push("73");
      tabelaSimbolos();
      estado73();
    }else if(token.equals(">=")){
      pilhaToken.push(">=");
      pilhaEstado.push("74");
      tabelaSimbolos();
      estado74();
    }else if(token.equals("=")){
      pilhaToken.push("=");
      pilhaEstado.push("75");
      tabelaSimbolos();
      estado75();
    }else if(token.equals("<>")){
      pilhaToken.push("<>");
      pilhaEstado.push("76");
      tabelaSimbolos();
      estado76();
    }else if((pilhaToken.top()).equals("B'")){
      pilhaEstado.push("70");
      estado70();
    }
    else{
      System.out.println("Syntax error: 42");
    }//fim else
  }//fim metodo estado42

  public void estado43(){
    System.out.println("estado 43");
    if(token.equals(";")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(",")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("THEN")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<=")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">=")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("=")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<>")){
      reduz(40);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 43");
    }//fim else
  }//fim metodo estado43

  public void estado44(){
    System.out.println("estado 44");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("77");
      estado77();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }
    else{
      System.out.println("Syntax error: 44");
    }//fim else
  }//fim metodo estado44

  public void estado45(){
    System.out.println("estado 45");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("78");
      estado78();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }else{
      System.out.println("Syntax error: 45");
    }//fim else
  }//fim metodo estado45

  public void estado46(){
    System.out.println("estado 46");
    if((pilhaToken.top()).equals("E'")){
      pilhaEstado.push("79");
      estado79();
    }
    else if(token.equals(";")){
      reduz(47);
      estado46Esp();
    }else if(token.equals(",")){
      reduz(47);
      estado46Esp();
    }else if(token.equals(")")){
      reduz(47);
      estado46Esp();
    }else if(token.equals("then")){
      reduz(47);
      estado46Esp();
    }else if(token.equals("ELSE")){
      reduz(47);
      estado46Esp();
    }else if(token.equals("do")){
      reduz(47);
      estado46Esp();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("67");
      tabelaSimbolos();
      estado67();
    }else if(token.equals("+")){
      pilhaToken.push("+");
      pilhaEstado.push("66");
      tabelaSimbolos();
      estado66();
    }else if(token.equals("*")){
      pilhaToken.push("*");
      pilhaEstado.push("68");
      tabelaSimbolos();
      estado68();
    }else if(token.equals("/")){
      pilhaToken.push("/");
      pilhaEstado.push("69");
      tabelaSimbolos();
      estado69();
    }else if(token.equals("<")){
      reduz(47);
      estado46Esp();
    }else if(token.equals("<=")){
      reduz(47);
      estado46Esp();
    }else if(token.equals(">")){
      reduz(47);
      estado46Esp();
    }else if(token.equals(">=")){
      reduz(47);
      estado46Esp();
    }else if(token.equals("=")){
      reduz(47);
      estado46Esp();
    }else if(token.equals("<>")){
      reduz(47);
      estado46Esp();
    }else{
      System.out.println("Syntax error: 46");
    }//fim else
  }//fim metodo estado46

  public void estado46Esp(){
    System.out.println("estado 46 esp");
     if((pilhaToken.top()).equals("E'")){
      pilhaEstado.push("79");
      estado79();
    }else{
      System.out.println("Syntax error: 46");
    }//fim else
  }//fim metodo estado46Esp

  public void estado47(){
    System.out.println("estado 47");
    if(token.equals("DO")){
      pilhaToken.push("DO");
      pilhaEstado.push("80");
      tabelaSimbolos();
      estado80();
    }else{
      System.out.println("Syntax error: 47");
    }//fim else
  }//fim metodo estado47

  public void estado48(){
    System.out.println("estado 48");
    if(token.equals(";")){
      pilhaToken.push(";");
      pilhaEstado.push("81");
      tabelaSimbolos();
      estado81();
    }else{
      System.out.println("Syntax error: 48");
    }//fim else
  }//fim metodo estado48

  public void estado49(){
    System.out.println("estado 49: " + token);
    if(token.equals(";")){
      reduz(7);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 49");
    }//fim else
  }//fim metodo estado49

  public void estado50(){
    System.out.println("estado 50");
    if(token.equals(";")){
      reduz(8);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 50");
    }//fim else
  }//fim metodo estado50

  public void estado51(){
    System.out.println("estado 51");
    if(token.equals(":")){
      reduz(10);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 51");
    }//fim else
  }//fim metodo estado51

  public void estado52(){
    System.out.println("estado 52");
    if(token.equals("END")){
      reduz(12);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 52");
    }//fim else
  }//fim metodo estado52

  public void estado53(){
    System.out.println("estado 53: " + token);
    System.out.println("topo da pilha: " + pilhaToken.top());
    System.out.println("topo da pilhaEstado: " + pilhaEstado.top());
    if(token.equals(";")){
      pilhaToken.push(";");
      pilhaEstado.push("82");
      tabelaSimbolos();
      estado82();
    }else{
      System.out.println("Syntax error: 53");
    }//fim else
  }//fim metodo estado53

  public void estado54(){
    System.out.println("estado 54");
    if(token.equals(";")){
      reduz(21);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(21);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 54");
    }//fim else
  }//fim metodo estado54

  public void estado55(){
    System.out.println("estado 55");
    if((pilhaToken.top()).equals("E'")){
      pilhaEstado.push("65");
      estado65();
    }else if(token.equals(";")){
      reduz(47);
      estado55Esp();
    }else if(token.equals(",")){
      reduz(47);
      estado55Esp();
    }else if(token.equals(")")){
      reduz(47);
      estado55Esp();
    }else if(token.equals("THEN")){
      reduz(47);
      estado55Esp();
    }else if(token.equals("ELSE")){
      reduz(47);
      estado55Esp();
    }else if(token.equals("DO")){
      reduz(47);
      estado55Esp();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("67");
      tabelaSimbolos();
      estado67();
    }else if(token.equals("+")){
      pilhaToken.push("+");
      pilhaEstado.push("66");
      tabelaSimbolos();
      estado66();
    }else if(token.equals("*")){
      pilhaToken.push("*");
      pilhaEstado.push("68");
      tabelaSimbolos();
      estado68();
    }else if(token.equals("/")){
      pilhaToken.push("/");
      pilhaEstado.push("69");
      tabelaSimbolos();
      estado69();
    }else if(token.equals("<")){
      reduz(47);
      estado55Esp();
    }else if(token.equals("<=")){
      reduz(47);
      estado55Esp();
    }else if(token.equals(">")){
      reduz(47);
      estado55Esp();
    }else if(token.equals(">=")){
      reduz(47);
      estado55Esp();
    }else if(token.equals("=")){
      reduz(47);
      estado55Esp();
    }else if(token.equals("<>")){
      reduz(47);
      estado55Esp();
    }else{
      System.out.println("Syntax error: 55");
    }//fim else
  }//fim metodo estado55

  public void estado55Esp(){
    System.out.println("estado 55esp");
    if((pilhaToken.top()).equals("E'")){
      pilhaEstado.push("65");
      estado65();
    }
    else{
      System.out.println("Syntax error: 55");
    }//fim else
  }//fim metodo estado55Esp


  public void estado56(){
    System.out.println("estado 56");
    if(token.equals(")")){
      pilhaToken.push(")");
      pilhaEstado.push("83");
      tabelaSimbolos();
      estado83();
    }else{
      System.out.println("Syntax error: 56");
    }//fim else
  }//fim metodo estado56

  public void estado57(){
    System.out.println("estado 57");
    if(token.equals(")")){
      pilhaToken.push(")");
      pilhaEstado.push("84");
      tabelaSimbolos();
      estado84();
    }else{
      System.out.println("Syntax error: 57");
    }//fim else
  }//fim metodo estado57

  public void estado58(){
    System.out.println("estado 58");
    if(token.equals(")")){
      pilhaToken.push(")");
      pilhaEstado.push("85");
      tabelaSimbolos();
      estado85();
    }else{
      System.out.println("Syntax error: 58");
    }//fim else
  }//fim metodo estado58

  public void estado59(){
    System.out.println("estado 59");
    if((pilhaToken.top()).equals("F'")){
      pilhaEstado.push("86");
      estado86();
    }else if(token.equals(",")){
      pilhaToken.push(",");
      pilhaEstado.push("87");
      tabelaSimbolos();
      estado87();
    }else if(token.equals(")")){
      reduz(32);
      estado59Esp();
    }else{
      System.out.println("Syntax error: 59");
    }//fim else
  }//fim metodo estado59

  public void estado59Esp(){
    System.out.println("estado 59Esp");
    if((pilhaToken.top()).equals("F'")){
      pilhaEstado.push("86");
      estado86();
    } else{
      System.out.println("Syntax error: 59");
    }//fim else
  }//fim metodo estado59Esp

    public void estado60(){
    System.out.println("Estado 60");
    if(token.equals(",")){
      reduz(33);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(33);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 60");
    }//fim else
  }//fim metodo estado60

  public void estado61(){
    System.out.println("Estado 61");
    if(token.equals(",")){
      reduz(34);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(34);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 61");
    }//fim else
  }//fim metodo estado61

  public void estado62(){
    System.out.println("Estado 62");
    if(token.equals(")")){
      pilhaToken.push(")");
      pilhaEstado.push("88");
      tabelaSimbolos();
      estado88();
    }else{
      System.out.println("Syntax error: 62");
    }//fim else
  }//fim metodo estado62

  public void estado63(){
    System.out.println("Estado 63");
    if(token.equals(";")){
      reduz(35);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(35);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 63");
    }//fim else
  }//fim metodo estado63

  public void estado64(){
    System.out.println("Estado 64");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("19");
      tabelaSimbolos();
      estado19();
    }else if(token.equals("BEGIN")){
      pilhaToken.push("BEGIN");
      pilhaEstado.push("24");
      tabelaSimbolos();
      estado24();
    }else if(token.equals("READ")){
      pilhaToken.push("READ");
      pilhaEstado.push("20");
      tabelaSimbolos();
      estado20();
    }else if(token.equals("READLN")){
      pilhaToken.push("READLN");
      pilhaEstado.push("21");
      tabelaSimbolos();
      estado21();
    }else if(token.equals("WRITE")){
      pilhaToken.push("WRITE");
      pilhaEstado.push("22");
      tabelaSimbolos();
      estado22();
    }else if(token.equals("WRITELN")){
      pilhaToken.push("WRITELN");
      pilhaEstado.push("23");
      tabelaSimbolos();
      estado23();
    }else if(token.equals("IF")){
      pilhaToken.push("IF");
      pilhaEstado.push("25");
      tabelaSimbolos();
      estado25();
    }else if(token.equals("WHILE")){
      pilhaToken.push("WHILE");
      pilhaEstado.push("26");
      tabelaSimbolos();
      estado26();
    }else if((pilhaToken.top()).equals("C")){
      pilhaEstado.push("89");
      estado89();
    }else if((pilhaToken.top()).equals("A")){
      pilhaEstado.push("13");
      estado13();
    }else if((pilhaToken.top()).equals("R")){
      pilhaEstado.push("14");
      estado14();
    }else if((pilhaToken.top()).equals("W")){
      pilhaEstado.push("15");
      estado15();
    }else if((pilhaToken.top()).equals("M")){
      pilhaEstado.push("16");
      estado16();
    }else if((pilhaToken.top()).equals("N")){
      pilhaEstado.push("17");
      estado17();
    }else if((pilhaToken.top()).equals("P")){
      pilhaEstado.push("18");
      estado18();
    }
    else{
      System.out.println("Syntax error: 64");
    }//fim else
  }//fim metodo estado64

  public void estado65(){
    System.out.println("Estado 65");
    if(token.equals(";")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(",")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("THEN")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<=")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">=")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("=")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<>")){
      reduz(48);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 65");
    }//fim else
  }//fim metodo estado65

  public void estado66(){
    System.out.println("Estado 66");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("90");
      estado90();
    }
    else{
      System.out.println("Syntax error: 66");
    }//fim else
  }//fim metodo estado66

  public void estado67(){
    System.out.println("Estado 67");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55(); 
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46(); 
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("91");
      estado91();
    }else{
      System.out.println("Syntax error: 67");
    }//fim else
  }//fim metodo estado67

  public void estado68(){
    System.out.println("Estado 68");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46(); 
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("92");
      estado92();
    }else{
      System.out.println("Syntax error: 68");
    }//fim else
  }//fim metodo estado68

  public void estado69(){
    System.out.println("Estado 69");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46(); 
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("93");
      estado93();
    }else{
      System.out.println("Syntax error: 69");
    }//fim else
  }//fim metodo estado69

  public void estado70(){
    System.out.println("Estado 70");
    if(token.equals("THEN")){
      reduz(51);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(51);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 70");
    }//fim else
  }//fim metodo estado70

  public void estado71(){
    System.out.println("Estado 71");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("94");
      estado94();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }else{
      System.out.println("Syntax error: 71");
    }//fim else
  }//fim metodo estado71

  public void estado72(){
    System.out.println("Estado 72");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("95");
      estado95();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }
    else{
      System.out.println("Syntax error: 72");
    }//fim else
  }//fim metodo estado72

  public void estado73(){
    System.out.println("Estado 73");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("96");
      estado96();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }
    else{
      System.out.println("Syntax error: 73");
    }//fim else
  }//fim metodo estado73

  public void estado74(){
    System.out.println("Estado 74");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("97");
      estado97();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }
    else{
      System.out.println("Syntax error: 74");
    }//fim else
  }//fim metodo estado74


  public void estado75(){
    System.out.println("Estado 75");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("98");
      estado98();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }else{
      System.out.println("Syntax error: 75");
    }//fim else
  }//fim metodo estado75

  public void estado76(){
    System.out.println("Estado 76");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    }else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    }else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    }else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    }else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("99");
      estado99();
    }else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    }else{
      System.out.println("Syntax error: 76");
    }//fim else
  }//fim metodo estado76

  public void estado77(){
    System.out.println("Estado 77");
    if(token.equals(";")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(",")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("THEN")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<=")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">=")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("=")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<>")){
      reduz(41);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 77");
    }//fim else
  }//fim metodo estado77

  public void estado78(){
    System.out.println("Estado 78: " + token);
    System.out.println("topo da pilha: " + pilhaToken.top());
    if(token.equals(")")){
      pilhaToken.push(")");
      pilhaEstado.push("100");
      tabelaSimbolos();
      estado100();
    }else{
      System.out.println("Syntax error: 78");
    }//fim else
  }//fim metodo estado78

  public void estado79(){
    System.out.println("Estado 79");
    if(token.equals(";")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(",")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("THEN")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<=")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">=")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("=")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<>")){
      reduz(49);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 79");
    }//fim else
  }//fim metodo estado79

  public void estado80(){
    System.out.println("Estado 80");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("19");
      tabelaSimbolos();
      estado19();
      
    }else if(token.equals("BEGIN")){
      pilhaToken.push("BEGIN");
      pilhaEstado.push("24");
      tabelaSimbolos();
      estado24();
    } else if(token.equals("READ")){
      pilhaToken.push("READ");
      pilhaEstado.push("20");
      tabelaSimbolos();
      estado20();
    }else if(token.equals("READLN")){
      pilhaToken.push("READLN");
      pilhaEstado.push("21");
      tabelaSimbolos();
      estado21();
    } else if(token.equals("WRITE")){
      pilhaToken.push("WRITE");
      pilhaEstado.push("22");
      tabelaSimbolos();
      estado22();
    } else if(token.equals("WRITELN")){
      pilhaToken.push("WRITELN");
      pilhaEstado.push("23");
      tabelaSimbolos();
      estado23();
    } else if(token.equals("IF")){
      pilhaToken.push("IF");
      pilhaEstado.push("25");
      tabelaSimbolos();
      estado25();
    } else if(token.equals("WHILE")){
      pilhaToken.push("WHILE");
      pilhaEstado.push("26");
      tabelaSimbolos();
      estado26();
    } else if((pilhaToken.top()).equals("C")){
      pilhaEstado.push("101");
      estado101();
    } else if((pilhaToken.top()).equals("A")){
      pilhaEstado.push("13");
      estado13();
    } else if((pilhaToken.top()).equals("R")){
      pilhaEstado.push("14");
      estado14();
    } else if((pilhaToken.top()).equals("W")){
      pilhaEstado.push("15");
      estado15();
    } else if((pilhaToken.top()).equals("M")){
      pilhaEstado.push("16");
      estado16();
    } else if((pilhaToken.top()).equals("N")){
      pilhaEstado.push("17");
      estado17();
    } else if((pilhaToken.top()).equals("P")){
      pilhaEstado.push("18");
      estado18();
    }
    else{
      System.out.println("Syntax error: 80");
    }//fim else
  }//fim metodo estado80


  public void estado81(){
    System.out.println("Estado 81");
    if((pilhaToken.top()).equals("V'")){
      pilhaEstado.push("102");
      estado102();
    }else if((pilhaToken.top()).equals("I")){
      pilhaEstado.push("103");
      estado103();
    }else if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("10");
      tabelaSimbolos();
      estado10();
      
    } else if(token.equals("BEGIN")){
      reduz(6);
      estado81Esp();
    }else{
      System.out.println("Syntax error: 81");
    }//fim else
  }//fim metodo estado81

  public void estado81Esp(){
    System.out.println("Estado 81Esp");
    if((pilhaToken.top()).equals("V'")){
      pilhaEstado.push("102");
      estado102();
    }else{
      System.out.println("Syntax error: 81");
    }//fim else
  }//fim metodo estado81Esp

  public void estado82(){
    System.out.println("Estado 82");
    if((pilhaToken.top()).equals("C")){
      pilhaEstado.push("53");
      estado53();
    }else if((pilhaToken.top()).equals("A")){
      pilhaEstado.push("13");
      estado13();
    }else if((pilhaToken.top()).equals("R")){
      pilhaEstado.push("14");
      estado14();
    }else if((pilhaToken.top()).equals("W")){
      pilhaEstado.push("15");
      estado15();
    }else if((pilhaToken.top()).equals("M")){
      pilhaEstado.push("16");
      estado16();
    }else if((pilhaToken.top()).equals("N")){
      pilhaEstado.push("17");
      estado17();
    }else if((pilhaToken.top()).equals("P")){
      pilhaEstado.push("18");
      estado18();
    }else if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("19");
      tabelaSimbolos();
      estado19();
    } else if(token.equals("BEGIN")){
      pilhaToken.push("BEGIN");
      pilhaEstado.push("24");
      tabelaSimbolos();
      estado24();
    }else if((pilhaToken.top()).equals("L'")){
      pilhaEstado.push("104");
      estado104();
    }else if(token.equals("END")){
      reduz(14);
      estado82Esp();
    }else if(token.equals("READ")){
      pilhaToken.push("READ");
      pilhaEstado.push("20");
      tabelaSimbolos();
      estado20();
    }else if(token.equals("READLN")){
      pilhaToken.push("READLN");
      pilhaEstado.push("21");
      tabelaSimbolos();
      estado21();
    } else if(token.equals("WRITE")){
      pilhaToken.push("WRITE");
      pilhaEstado.push("22");
      tabelaSimbolos();
      estado22();
    } else if(token.equals("WRITELN")){
      pilhaToken.push("WRITELN");
      pilhaEstado.push("23");
      tabelaSimbolos();
      estado23();
    } else if(token.equals("IF")){
      pilhaToken.push("IF");
      pilhaEstado.push("25");
      tabelaSimbolos();
      estado25();
    } else if(token.equals("WHILE")){
      pilhaToken.push("WHILE");
      pilhaEstado.push("26");
      tabelaSimbolos();
      estado26();
    }else{
      System.out.println("Syntax error: 82");
    }//fim else
  }//fim metodo estado82

  public void estado82Esp(){
    System.out.println("Estado 82Esp");
    if((pilhaToken.top()).equals("L'")){
      pilhaEstado.push("104");
      estado104();
    }else if((pilhaToken.top()).equals("C")){
      pilhaEstado.push("53");
      estado53();
    }else if((pilhaToken.top()).equals("A")){
      pilhaEstado.push("13");
      estado13();
    }else if((pilhaToken.top()).equals("R")){
      pilhaEstado.push("14");
      estado14();
    }else if((pilhaToken.top()).equals("W")){
      pilhaEstado.push("15");
      estado15();
    }else if((pilhaToken.top()).equals("M")){
      pilhaEstado.push("16");
      estado16();
    }else if((pilhaToken.top()).equals("N")){
      pilhaEstado.push("17");
      estado17();
    }else if((pilhaToken.top()).equals("P")){
      pilhaEstado.push("18");
      estado18();
    }else{
      System.out.println("Syntax error: 82 esp");
    }//fim else
  }//fim metodo estado82

  public void estado83(){
    System.out.println("Estado 83");
    if(token.equals(";")){
      reduz(22);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    } else if(token.equals("ELSE")){
      reduz(22);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 83");
    }//fim else
  }//fim metodo estado83

  public void estado84(){
    System.out.println("Estado 84");
    if(token.equals(";")){
      reduz(24);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    } else if(token.equals("ELSE")){
      reduz(24);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 84");
    }//fim else
  }//fim metodo estado84

  public void estado85(){
    System.out.println("Estado 85");
    if(token.equals(";")){
      reduz(26);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    } else if(token.equals("ELSE")){
      reduz(26);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 85");
    }//fim else
  }//fim metodo estado85

  public void estado86(){
    System.out.println("Estado 86");
    if(token.equals(")")){
      reduz(30);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    } else{
      System.out.println("Syntax error: 86");
    }//fim else
  }//fim metodo estado86

  public void estado87(){
    System.out.println("Estado 87");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("55");
      tabelaSimbolos();
      estado55();
    } else if(token.equals("(")){
      pilhaToken.push("(");
      pilhaEstado.push("45");
      tabelaSimbolos();
      estado45();
    } else if(tipo.equals("identificador")){
      pilhaToken.push("string");
      pilhaEstado.push("60");
      tabelaSimbolos();
      estado60();
    } else if(token.equals("-")){
      pilhaToken.push("-");
      pilhaEstado.push("44");
      tabelaSimbolos();
      estado44();
    } else if(tipo.equals("numero_inteiro")){
      pilhaToken.push("numero_inteiro");
      pilhaEstado.push("46");
      tabelaSimbolos();
      estado46();
    } else if((pilhaToken.top()).equals("F")){
      pilhaEstado.push("105");
      estado105();
    } else if((pilhaToken.top()).equals("G")){
      pilhaEstado.push("59");
      estado59();
    } else if((pilhaToken.top()).equals("E")){
      pilhaEstado.push("61");
      estado61();
    } else if((pilhaToken.top()).equals("X")){
      pilhaEstado.push("43");
      estado43();
    } else{
      System.out.println("Syntax error: 87");
    }//fim else
  }//fim metodo estado87

  public void estado88(){
    System.out.println("Estado 88");
    if(token.equals(";")){
      reduz(28);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    } else if(token.equals("ELSE")){
      reduz(28);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 88");
    }//fim else
  }//fim metodo estado88

  public void estado89(){
    System.out.println("Estado 89");
    if((pilhaToken.top()).equals("N'")){
      pilhaEstado.push("106");
      estado106();
    }else if(token.equals(";")){
      reduz(38);
      estado89Esp();
    } else if(token.equals("ELSE")){
      pilhaToken.push("ELSE");
      pilhaEstado.push("107");
      tabelaSimbolos();
      estado107();
    }else{
      System.out.println("Syntax error: 89");
    }//fim else
  }//fim metodo estado89

  public void estado89Esp(){
    System.out.println("Estado 89 Esp");
    if((pilhaToken.top()).equals("N'")){
      pilhaEstado.push("106");
      estado106();
    }else{
      System.out.println("Syntax error: 89");
    }//fim else
  }//fim metodo estado89Esp

  public void estado90(){
    System.out.println("Estado 90");
    if(token.equals(";")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(",")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("THEN")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<=")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">=")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("=")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<>")){
      reduz(43);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 90");
    }//fim else
  }//fim metodo estado90

  public void estado91(){
    System.out.println("Estado 91");
    if(token.equals(";")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(",")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("THEN")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<=")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">=")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("=")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<>")){
      reduz(44);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 91");
    }//fim else
    
  }//fim metodo estado91

  public void estado92(){
    System.out.println("Estado 92");
    if(token.equals(";")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(",")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("THEN")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<=")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">=")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("=")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<>")){
      reduz(45);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 92");
    }//fim else
  }//fim metodo estado92

  public void estado93(){
    System.out.println("Estado 93");
    if(token.equals(";")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(",")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("THEN")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<=")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">=")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("=")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<>")){
      reduz(46);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 93");
    }//fim else
  }//fim metodo estado93

  public void estado94(){
    System.out.println("Estado 94");
    if(token.equals("THEN")){
      reduz(52);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(52);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 94");
    }//fim else
  }//fim metodo estado94

  public void estado95(){
    System.out.println("Estado 95");
    if(token.equals("THEN")){
      reduz(53);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(53);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 95");
    }//fim else
  }//fim metodo estado95

  public void estado96(){
    System.out.println("Estado 96");
    if(token.equals("THEN")){
      reduz(54);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(54);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 96");
    }//fim else
  }//fim metodo estado96

  public void estado97(){
    System.out.println("Estado 97");
    if(token.equals("THEN")){
      reduz(55);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(55);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 97");
    }//fim else
  }//fim metodo estado97

  public void estado98(){
    System.out.println("Estado 98");
    if(token.equals("THEN")){
      reduz(56);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(56);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 98");
    }//fim else
  }//fim metodo estado98


  public void estado99(){
    System.out.println("Estado 99");
    if(token.equals("THEN")){
      reduz(57);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(57);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }
    else{
      System.out.println("Syntax error: 99");
    }//fim else
  }//fim metodo estado99

  public void estado100(){
    System.out.println("Estado 100");
    if(token.equals(";")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(",")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(")")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("THEN")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("ELSE")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("DO")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<=")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals(">=")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("=")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else if(token.equals("<>")){
      reduz(42);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 100");
    }//fim else
  }//fim metodo estado100

    public void estado101(){
      System.out.println("Estado 101");
    if(token.equals(";")){
      reduz(39);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    } else if(token.equals("ELSE")){
      reduz(39);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 101");
    }//fim else
  }//fim metodo estado101

  public void estado102(){
    System.out.println("Estado 102");
    if(token.equals("BEGIN")){
      reduz(4);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 102");
    }//fim else
  }//fim metodo estado102

  public void estado103(){
    System.out.println("Estado 103");
    if(token.equals(":")){
      pilhaToken.push(":");
      pilhaEstado.push("108");
      tabelaSimbolos();
      estado108();
    }else{
      System.out.println("Syntax error: 103");
    }//fim else
  }//fim metodo estado103

  public void estado104(){
    System.out.println("Estado 104");
    if(token.equals("END")){
      reduz(13);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 104");
    }//fim else
  }//fim metodo estado104

  public void estado105(){
    System.out.println("Estado 105");
    if(token.equals(")")){
      reduz(31);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 105");
    }//fim else
  }//fim metodo estado105

  public void estado106(){
    System.out.println("Estado 106");
    if(token.equals(";")){
      reduz(36);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    } else if(token.equals("ELSE")){
      reduz(36);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    } else{
      System.out.println("Syntax error: 106");
    }//fim else
  }//fim metodo estado106

  public void estado107(){
    System.out.println("Estado 107");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("19");
      tabelaSimbolos();
      estado19();
    } else if(token.equals("BEGIN")){
      pilhaToken.push("BEGIN");
      pilhaEstado.push("24");
      tabelaSimbolos();
      estado24();
    } else if(token.equals("READ")){
      pilhaToken.push("READ");
      pilhaEstado.push("20");
      tabelaSimbolos();
      estado20();
    } else if(token.equals("READLN")){
      pilhaToken.push("READLN");
      pilhaEstado.push("21");
      tabelaSimbolos();
      estado21();
    } else if(token.equals("WRITE")){
      pilhaToken.push("WRITE");
      pilhaEstado.push("22");
      tabelaSimbolos();
      estado22();
    } else if(token.equals("WRITELN")){
      pilhaToken.push("WRITELN");
      pilhaEstado.push("23");
      tabelaSimbolos();
      estado23();
    } else if(token.equals("IF")){
      pilhaToken.push("IF");
      pilhaEstado.push("25");
      tabelaSimbolos();
      estado25();
    } else if(token.equals("WHILE")){
      pilhaToken.push("WHILE");
      pilhaEstado.push("26");
      tabelaSimbolos();
      estado26();
    } else if((pilhaToken.top()).equals("C")){
      pilhaEstado.push("109");
      estado109();
    }else if((pilhaToken.top()).equals("A")){
      pilhaEstado.push("13");
      estado13();
    }else if((pilhaToken.top()).equals("R")){
      pilhaEstado.push("14");
      estado14();
    }else if((pilhaToken.top()).equals("W")){
      pilhaEstado.push("15");
      estado15();
    }else if((pilhaToken.top()).equals("M")){
      pilhaEstado.push("16");
      estado16();
    }else if((pilhaToken.top()).equals("N")){
      pilhaEstado.push("17");
      estado17();
    }else if((pilhaToken.top()).equals("P")){
      pilhaEstado.push("18");
      estado18();
    }else{
      System.out.println("Syntax error: 107");
    }//fim else
  }//fim metodo estado107

  public void estado108(){
    System.out.println("Estado 108");
    if(tipo.equals("INTEGER")){
      pilhaToken.push("INTEGER");
      pilhaEstado.push("49");
      tabelaSimbolos();
      estado49();
    } else if(tipo.equals("identificador")){
      pilhaToken.push("BOOLEAN");
      pilhaEstado.push("50");
      tabelaSimbolos();
      estado50();
    } else if((pilhaToken.top()).equals("T")){
      pilhaEstado.push("110");
      estado110();
    }else{
      System.out.println("Syntax error: 108");
    }//fim else
  }//fim metodo estado108

  public void estado109(){
    System.out.println("Estado 109");
    if(token.equals(";")){
      reduz(37);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    } else if(token.equals("ELSE")){
      reduz(37);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    } else{
      System.out.println("Syntax error: 109");
    }//fim else
  }//fim metodo estado109

  public void estado110(){
    System.out.println("Estado 110");
    if(token.equals(";")){
      pilhaToken.push(";");
      pilhaEstado.push("111");
      tabelaSimbolos();
      estado111();
    }else{
      System.out.println("Syntax error: 110");
    }//fim else
  }//fim metodo estado110

  public void estado111(){
    System.out.println("Estado 111");
    if(tipo.equals("identificador")){
      pilhaToken.push("identificador");
      pilhaEstado.push("10");
      tabelaSimbolos();
      estado10();
    } else if(token.equals("BEGIN")){
      reduz(6);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    } else if((pilhaToken.top()).equals("V'")){
      pilhaEstado.push("112");
      estado112();
    }else if((pilhaToken.top()).equals("I")){
      pilhaEstado.push("103");
      estado103();
    }else{
      System.out.println("Syntax error: 111");
    }//fim else
  }//fim metodo estado111

  public void estado112(){
    System.out.println("Estado 112");
    if(token.equals("BEGIN")){
      reduz(5);
      int est = Integer.parseInt(pilhaEstado.top());
      chamaEstado(est);
    }else{
      System.out.println("Syntax error: 112");
    }//fim else
  }//fim metodo estado112


//acho que tera que desempilhar os estados junto aos tokens
  public void reduz(int num){
    switch (num) {
      case 0:
        System.out.println("reduz 0");
        while(!(pilhaToken.top().equals("S"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("S'");
        break;
      case 1:
        System.out.println("reduz 1");
        while(!(pilhaToken.top().equals("PROGRAM"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("S");
        break;
      case 2:
        System.out.println("reduz 2");
        while(!(pilhaToken.top().equals("VAR"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("D");
        break;
      case 3:
        System.out.println("reduz 3");
        //pilhaToken.push("D");
        break;
      case 4:
        System.out.println("reduz 4");
        while(!(pilhaToken.top().equals("I"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("V");
        break;
      case 5:
        System.out.println("reduz 5");
        while(!(pilhaToken.top().equals("I"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("V'");
        break;
      case 6:
        System.out.println("reduz 6");
        pilhaToken.push("V'");
        break;
      case 7:
        System.out.println("reduz 7");
        while(!(pilhaToken.top().equals("INTEGER"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("T");
        
        break;
      case 8:
        System.out.println("reduz 8");
        while(!(pilhaToken.top().equals("BOOLEAN"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("T");
        break;
      case 9:
        System.out.println("reduz 9");
        while(!(pilhaToken.top().equals("identificador"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("I");
        break;
      case 10:
        System.out.println("reduz 10");
        while(!(pilhaToken.top().equals(","))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("I'");
        break;
      case 11:
        System.out.println("reduz 11");
        pilhaToken.push("I'");
        break;
      case 12:
        System.out.println("reduz 12");
        while(!(pilhaToken.top().equals("C"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("L");
        break;
      case 13:
        System.out.println("reduz 13");
        while(!(pilhaToken.top().equals("C"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("L'");
        break;
      case 14:
        System.out.println("reduz 14");
        pilhaToken.push("L'");
        break;
      case 15:
        System.out.println("reduz 15");
        while(!(pilhaToken.top().equals("A"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("C");
        break;
      case 16:
        System.out.println("reduz 16");
        while(!(pilhaToken.top().equals("R"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("C");
        break;
      case 17:
        System.out.println("reduz 17");
        while(!(pilhaToken.top().equals("W"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("C");
        break;
      case 18:
        System.out.println("reduz 18");
        while(!(pilhaToken.top().equals("M"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("C");
        break;
      case 19:
        System.out.println("reduz 19");
        while(!(pilhaToken.top().equals("N"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("C");
        break;
      case 20:
        System.out.println("reduz 20");
        while(!(pilhaToken.top().equals("P"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("C");
        break;
      case 21:
        System.out.println("reduz 21");
        while(!(pilhaToken.top().equals("identificador"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("A");
        break;
      case 22:
        System.out.println("reduz 22");
        while(!(pilhaToken.top().equals("READ"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("R");
        break;
      case 23:
        System.out.println("reduz 23");
        while(!(pilhaToken.top().equals("READLN"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("R");
        break;
      case 24:
        System.out.println("reduz 24");
        while(!(pilhaToken.top().equals("("))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("R'");
        break;
      case 25:
        System.out.println("reduz 25");
        pilhaToken.push("R'");
        break;
      case 26:
        System.out.println("reduz 26");
        while(!(pilhaToken.top().equals("WRITE"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("W");
        break;
      case 27:
        System.out.println("reduz 27");
        while(!(pilhaToken.top().equals("WRITELN"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("W");
        break;
      case 28:
        System.out.println("reduz 28");
        while(!(pilhaToken.top().equals("("))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        break;
      case 29:
        System.out.println("reduz 29");
        pilhaToken.push("W'");
        break;
      case 30:
        System.out.println("reduz 30");
         while(!(pilhaToken.top().equals("G"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("F");
        break;
      case 31:
        System.out.println("reduz 31");
        while(!(pilhaToken.top().equals(","))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("F'");
        break;
      case 32:
        System.out.println("reduz 32");
        pilhaToken.push("F'");
        break;
      case 33:
        System.out.println("reduz 33");
        while(!(pilhaToken.top().equals("string"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("G");
        break;
      case 34:
        System.out.println("reduz 34");
         while(!(pilhaToken.top().equals("E"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("G");
        break;
      case 35:
        System.out.println("reduz 35");
        while(!(pilhaToken.top().equals("BEGIN"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("M");
        break;
      case 36:
        System.out.println("reduz 36");
        while(!(pilhaToken.top().equals("IF"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("N");
        break;
      case 37:
        System.out.println("reduz 37");
        while(!(pilhaToken.top().equals("ELSE"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("N'");
        break;
      case 38:
        System.out.println("reduz 38");
        pilhaToken.push("N'");
        break;
      case 39:
        System.out.println("reduz 39");
        while(!(pilhaToken.top().equals("WHILE"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("P");
        break;
      case 40:
        System.out.println("reduz 40");
        while(!(pilhaToken.top().equals("X"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("E");
        break;
      case 41:
        System.out.println("reduz 41");
        while(!(pilhaToken.top().equals("-"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("E");
        break;
      case 42:
        System.out.println("reduz 42");
        while(!(pilhaToken.top().equals("("))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("E");
        break;
      case 43:
        System.out.println("reduz 43");
        while(!(pilhaToken.top().equals("+"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("E'");
        break;
      case 44:
        System.out.println("reduz 44");
        while(!(pilhaToken.top().equals("-"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("E'");
        break;
      case 45:
        System.out.println("reduz 45");
        while(!(pilhaToken.top().equals("*"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("E'");
        break;
      case 46:
        System.out.println("reduz 46");
        while(!(pilhaToken.top().equals("/"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("E'");
        break;
      case 47:
        System.out.println("reduz 47");
        pilhaToken.push("E'");
        break;
      case 48:
        System.out.println("reduz 48");
        while(!(pilhaToken.top().equals("identificador"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("X");
        break;
      case 49:
        System.out.println("reduz 49");
        while(!(pilhaToken.top().equals("numero_inteiro"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("X");
        break;
      case 50:
        System.out.println("reduz 50");
        while(!(pilhaToken.top().equals("identificador"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("B");
        break;
      case 51:
        System.out.println("reduz 51");
        while(!(pilhaToken.top().equals("E"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("B");
        break;
      case 52:
        System.out.println("reduz 52");
        while(!(pilhaToken.top().equals("<"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("B'");
        break;
      case 53:
        System.out.println("reduz 53");
        while(!(pilhaToken.top().equals("<="))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("B'");
        break;
      case 54:
        System.out.println("reduz 54");
        while(!(pilhaToken.top().equals(">"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("B'");
        break;
      case 55:
        System.out.println("reduz 55");
        while(!(pilhaToken.top().equals(">="))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("B'");
        break;
      case 56:
        System.out.println("reduz 56");
        while(!(pilhaToken.top().equals("="))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("B'");
        break;
      case 57:
        System.out.println("reduz 57");
        while(!(pilhaToken.top().equals("<>"))){
          System.out.println("desempilhei o token: " +  pilhaToken.pop());
          System.out.println("desempilhei o estado: " + pilhaEstado.pop());
        }
        pilhaToken.pop();
        pilhaEstado.pop();
        pilhaToken.push("B'");
        break;
      default:
        System.out.println("Error: Reduce not found: " + num);
        break;
    }//fim switch
  }//fim reduz


  public void chamaEstado(int estado){
    switch (estado) {
      case 0:
        estado0();
        break;
      case 1:
        estado1();
        break;
      case 2:
        estado2();
        break;
      case 3:
        estado3();
        break;
      case 4:
        estado4();
        break;
      case 5:
        estado5();
        break;
      case 6:
        estado6();
        break;
      case 7:
        estado7();
        break;
      case 8:
        estado8();
        break;
      case 9:
        estado9();
        break;
      case 10:
        estado10();
        break;
      case 11:
        estado11();
        break;
      case 12:
        estado12();
        break;
      case 13:
        estado13();
        break;
      case 14:
        estado14();
        break;
      case 15:
        estado15();
        break;
      case 16:
        estado16();
        break;
      case 17:
        estado17();
        break;
      case 18:
        estado18();
        break;
      case 19:
        estado19();
        break;
      case 20:
        estado20();
        break;
      case 21:
        estado21();
        break;
      case 22:
        estado22();
        break;
      case 23:
        estado23();
        break;
      case 24:
        estado24();
        break;
      case 25:
        estado25();
        break;
      case 26:
        estado26();
        break;
      case 27:
        estado27();
        break;
      case 28:
        estado28();
        break;
      case 29:
        estado29();
        break;
      case 30:
        estado30();
        break;
      case 31:
        estado31();
        break;
      case 32:
        estado32();
        break;
      case 33:
        estado33();
        break;
      case 34:
        estado34();
        break;
      case 35:
        estado35();
        break;
      case 36:
        estado36();
        break;
      case 37:
        estado37();
        break;
      case 38:
        estado38();
        break;
      case 39:
        estado39();
        break;
      case 40:
        estado40();
        break;
      case 41:
        estado41();
        break;
      case 42:
        estado42();
        break;
      case 43:
        estado43();
        break;
      case 44:
        estado44();
        break;
      case 45:
        estado45();
        break;
      case 46:
        estado46();
        break;
      case 47:
        estado47();
        break;
      case 48:
        estado48();
        break;
      case 49:
        estado49();
        break;
      case 50:
        estado50();
        break;
      case 51:
        estado51();
        break;
      case 52:
        estado52();
        break;
      case 53:
        estado53();
        break;
      case 54:
        estado54();
        break;
      case 55:
        estado55();
        break;
      case 56:
        estado56();
        break;
      case 57:
        estado57();
        break;
      case 58:
        estado58();
        break;
      case 59:
        estado59();
        break;
      case 60:
        estado60();
        break;
      case 61:
        estado61();
        break;
      case 62:
        estado62();
        break;
      case 63:
        estado63();
        break;
      case 64:
        estado64();
        break;
      case 65:
        estado65();
        break;
      case 66:
        estado66();
        break;
      case 67:
        estado67();
        break;
      case 68:
        estado68();
        break;
      case 69:
        estado69();
        break;
      case 70:
        estado70();
        break;
      case 71:
        estado71();
        break;
      case 72:
        estado72();
        break;
      case 73:
        estado73();
        break;
      case 74:
        estado74();
        break;
      case 75:
        estado75();
        break;
      case 76:
        estado76();
        break;
      case 77:
        estado77();
        break;
      case 78:
        estado78();
        break;
      case 79:
        estado79();
        break;
      case 80:
        estado80();
        break;
      case 81:
        estado81();
        break;
      case 82:
        estado82();
        break;
      case 83:
        estado83();
        break;
      case 84:
        estado84();
        break;
      case 85:
        estado85();
        break;
      case 86:
        estado86();
        break;
      case 87:
        estado87();
        break;
      case 88:
        estado88();
        break;
      case 89:
        estado89();
        break;
      case 90:
        estado90();
        break;
      case 91:
        estado91();
        break;
      case 92:
        estado92();
        break;
      case 93:
        estado93();
        break;
      case 94:
        estado94();
        break;
      case 95:
        estado95();
        break;
      case 96:
        estado96();
        break;
      case 97:
        estado97();
        break;
      case 98:
        estado98();
        break;
      case 99:
        estado99();
        break;
      case 100:
        estado100();
        break;
      case 101:
        estado101();
        break;
      case 102:
        estado102();
        break;
      case 103:
        estado103();
        break;
      case 104:
        estado104();
        break;
      case 105:
        estado105();
        break;
      case 106:
        estado106();
        break;
      case 107:
        estado107();
        break;
      case 108:
        estado108();
        break;
      case 109:
        estado109();
        break;
      case 110:
        estado110();
        break;
      case 111:
        estado111();
        break;
      case 112:
        estado112();
        break;
      default:
        System.out.println("Error: State not found!");
        break;
    }//fim switch
  }//fim metodo chamaEstado
  public void setControlador(Controlador controlador){
    this.c = controlador;
  }//fim metodo setControlador
}//fim metodo analisadorSintatico

/*
token.equals("")
(pilhaToken.top()).equals("")

else{
      System.out.println("Syntax error: ");
    }

*/


// processo para reduzir -> desempilha o estado atual do pilhaEstado ( pilhaEstado.pop() ), da um pilhaEstado.top() e chama o estado que esta no topo
// ex: pilhaToken.top() retorna 0, entao vamos para o estado 0, apos estar no estado 0 realiza o desvio, para realizar o desvio faz:
// verifica o topo da pilha de tokens que no caso quem vai estar la é a variavel resultante da reducao, entao eh verificado por ex: quando está
// no estado 0 e vê um A empilha 2, porem como estamos usando estados nao iremos empilhar o 2 mas sim chamar o estado 2 e o codigo prossegue
// lendo a entrada normalmente.