package pilha;

/*
Implementando operações com pilhas em Java
Criando a Classe Pilha
Implementamos as funções isEmpty, top, push e pop
*/
public class Pilha {
   static final int MAX = 1000;
   int top;
   String a[] = new String[MAX]; // Define tamanho máximo da pilha   

   // Construtor
   public Pilha() {
      top = -1;
   }

   // Métodos da pilha
   public boolean isEmpty() {
     return (top < 0);
   }

   public boolean push(String x) {
      if (top >= (MAX-1)) {
         System.out.println("Estouro de Pilha!");
         return false;
      }
      else {
         a[++top] = x;
         return true;
      }
   }
   public String pop() {
      if (top < 0) {
         System.out.println("Pilha Vazia!");
         return "null";
      }
      else {
         String x = a[top--];
         return x;
      }
   }
   public String top() {
      if (top < 0) {
         System.out.println("Pilha Vazia!");
         return "null";
      }
      else {
         return a[top];
      }
   }
}