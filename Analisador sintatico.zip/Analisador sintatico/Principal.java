import controlador.Controlador;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class Principal extends Application{

    public static Scene telaInterface;
    
    @Override
    public void start(Stage primaryStage)throws IOException {
        Parent fxmlInterface = FXMLLoader.load(getClass().getResource("/tela/interface.fxml"));
        telaInterface = new Scene(fxmlInterface);
        primaryStage.setScene(telaInterface); // a cena eh passada para o palco
        primaryStage.setTitle("Analisador Sintatico"); // muda o titulo do programa
        primaryStage.show(); // exibe a tela para o usuario
    }//Fim start

    public static void main(String args[]){
      launch(args);
    }//fim main

  }//fim classe Principal