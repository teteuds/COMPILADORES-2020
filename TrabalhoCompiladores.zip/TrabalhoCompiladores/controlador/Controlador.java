package controlador;

import java.util.concurrent.Semaphore;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.scene.control.*;
import javafx.fxml.FXML;
import javafx.application.Platform;
import javafx.scene.control.Slider;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.Date;
import analisadorLexico.AnalisadorLexico;

/*********************************************************************
* Classe: Controlador
* Funcao: controla todas as funcoes da tela
******************************************************************* */
public class Controlador implements Initializable {

  @FXML public TextField inputDados;
  @FXML public Button btnDados;
  @FXML public TextArea txtResultado;

  AnalisadorLexico analisadorLex = new AnalisadorLexico();

  /* ***************************************************************
  * Metodo: initialize
  * Funcao: vai ser a primeira coisa a ser executada na inicializacao da GUI
  * Parametros: url do tipo URL e rb do tipo ResourceBundle
  * Retorno: void
  *************************************************************** */
  @Override
  public void initialize(URL url, ResourceBundle rb) {
  	analisadorLex.setControl(this);
		analisadorLex.adicionarPalavrasReservadas();
		analisadorLex.adicionarAlfabeto();
		analisadorLex.adicionarNumeros();
	  analisadorLex.adicionarOperadoresRelacionais();
	  analisadorLex.adicionarOperadoresLogicos();
	  analisadorLex.adicionarOperadoresAritmeticos();
	  analisadorLex.adicionarSimbolosEspeciais();
	  analisadorLex.adicionarAtribuicao();
	  //analisadorLex.adicionarFim();
  } //fim do initialize

  public void enviarDados(){
    txtResultado.setText("");
  	String dados = inputDados.getText();
    String programa = "";
    try {
      FileReader arq = new FileReader(dados);
      BufferedReader lerArq = new BufferedReader(arq);
 
      String linha = lerArq.readLine(); // lê a primeira linha
      programa += linha;
      // a variável "linha" recebe o valor "null" quando o processo
      // de repetição atingir o final do arquivo texto
      while (linha != null) {
        //System.out.printf("%s\n", linha);
        linha = lerArq.readLine(); // lê da segunda até a última linha
        programa += " " + linha;
      }//fim while
      //System.out.println(programa);
      arq.close();
    } catch (IOException e) {
        System.err.printf("Erro na abertura do arquivo: %s.\n",
          e.getMessage());
    }
    programa = programa.replace("null","");
    System.out.println(programa);
  	analisadorLex.recebeEntrada(programa);
    corrige();
    corrige();
  }//fim metodo enviarDados

  public void corrige(){
    txtResultado.setText("");
    String dados = inputDados.getText();
    String programa = "";
    try {
      FileReader arq = new FileReader(dados);
      BufferedReader lerArq = new BufferedReader(arq);
 
      String linha = lerArq.readLine(); // lê a primeira linha
      programa += linha;
      // a variável "linha" recebe o valor "null" quando o processo
      // de repetição atingir o final do arquivo texto
      while (linha != null) {
        //System.out.printf("%s\n", linha);
        linha = lerArq.readLine(); // lê da segunda até a última linha
        programa += " " + linha;
      }//fim while
      //System.out.println(programa);
      arq.close();
    } catch (IOException e) {
        System.err.printf("Erro na abertura do arquivo: %s.\n",
          e.getMessage());
    }
    programa = programa.replace("null","");
    System.out.println(programa);
    analisadorLex.recebeEntrada(programa);
  }//fim metodo corrige

}//Fim classe Controlador