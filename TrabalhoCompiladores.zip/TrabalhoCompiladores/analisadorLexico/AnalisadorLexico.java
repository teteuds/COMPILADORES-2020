package analisadorLexico;

import controlador.Controlador;
import java.util.ArrayList; 
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.io.*;

/*ABSOLUTE ARRAY BEGIN CASE CHAR CONST DIV DO DOWTO ELSE END EXTERNAL FILE FOR FORWARD FUNC FUNCTION GOTO IF IMPLEMENTATION IN 

INTEGER INTERFACE INTERRUPT LABEL MAIN NIL NIT OF PACKED PROC PROGRAM REAL RECORD REPEAT SET SHL SHR STRING THEN TO TYPE UNIT UNTIL USES VAR WHILE WITH XOR*/
public class AnalisadorLexico{
    /*ArrayList<String> tabelaSimbolos = new ArrayList<String>();
    tabelaSimbolos.add();*/
    String simbEspecialGeral = "";

    Boolean ignorar = false;
    String tabelaSimbolos[][] = new String[10000][10000];
    ArrayList<String> letras = new ArrayList<String>();
    ArrayList<String> numeros = new ArrayList<String>();
    ArrayList<String> palavrasReconhecidas = new ArrayList<String>();
    ArrayList<String> simbolosEspeciais = new ArrayList<String>();
    Boolean crtlAspasDuplas = false;
    Boolean crtlAspasSimples = false;
    Boolean crtlInicioDeComentario = false;
    Boolean crtlFimDeComentario = false;
    Boolean crtlSimboloEsp = false;
    Boolean crtlNumero = false;
    Boolean crtlNumMalFormado = false;

    String dadosMalFormados = "";
    int indiceDados = 0;
    int indiceGeral = 0;
    String[] dadosSeparados;
    String lexemaEtoken = "";
    String lexemaEtoken2 = "";
    String lexemaEtoken3 = "";
    String resultadoFinal = "";

    Controlador controlador;

  	public File arquivo = new File("C:/Users/tciot/Desktop/faculdade/Materias/compiladores/trabalho/Analisador sintatico/tabsim" + ".txt");
	public FileWriter grava;


    /*{"ABSOLUTE", "palavra_reservada", "ARRAY", "palavra_reservada", "BEGIN" , "palavra_reservada","CASE" , "palavra_reservada","CHAR" ,
     "palavra_reservada","CONST" , "palavra_reservada","DIV" , "palavra_reservada","DO" , "palavra_reservada","DOWTO" , "palavra_reservada","ELSE" , "palavra_reservada","END" ,
      "palavra_reservada","EXTERNAL" , "palavra_reservada","FILE" , "palavra_reservada","FOR" , "palavra_reservada","FORWARD" , "palavra_reservada","FUNC" , 
      "palavra_reservada","FUNCTION" , "palavra_reservada","GOTO" , "palavra_reservada","IF" , "palavra_reservada","IMPLEMENTATION", "palavra_reservada", "IN", "palavra_reservada", 
    "INTEGER", "palavra_reservada", "INTERFACE", "palavra_reservada", "INTERRUPT", "palavra_reservada", "LABEL", "palavra_reservada", "MAIN", "palavra_reservada", 
    "NIL", "palavra_reservada", "NIT", "palavra_reservada", "OF", "palavra_reservada", "PACKED", "palavra_reservada", "PROC", "palavra_reservada", "PROGRAM", 
    "palavra_reservada", "REAL", "palavra_reservada", "RECORD", "palavra_reservada", "REPEAT",  "palavra_reservada","SET", "palavra_reservada", "SHL",  "palavra_reservada",
    "SHR", "palavra_reservada", "STRING", "palavra_reservada", "THEN", "palavra_reservada", "TO", "palavra_reservada", "TYPE", "palavra_reservada", "UNIT", 
    "palavra_reservada", "UNTIL", "palavra_reservada", "USES", "palavra_reservada", "VAR", "palavra_reservada", "WHILE", "palavra_reservada", "WITH", 
    "palavra_reservada", "XOR", "palavra_reservada",};
    */

  

  //falta adicionar simbolos
  public void recebeEntrada(String dados){
    //System.out.println(dados);
    //String lexemaEtoken = "";
    //String lexemaEtoken2 = "";
    //String lexemaEtoken3 = "";
    int contadorwhile = 1;
    String aux2 = "";
    String aspDpl = "\"";
    String aspSpl = "\'";

    controlador.txtResultado.setText(" ");
  	resultadoFinal = "";

    try{ 
    	grava = new FileWriter(arquivo, false);


      dados = dados.toUpperCase();
      dados = dados.replace(";"," ;");
      dados = dados.replace(","," , ");
      dados = dados.replace(":"," : ");
      dados = dados.replace(".", " . ");
      dados = dados.replace("("," ( ");
      dados = dados.replace(")"," ) ");
      dados = dados.replace("=", " = ");// igualdade 
      dados = dados.replace(" :  = ", " := "); //atribuicao
      dados = dados.replace("-", "- ");
      dados = dados.replace("+", " + ");
      dados = dados.replace("/*"," /* ");
      dados = dados.replace("*/"," */ ");
      dados = dados.replace(aspDpl," \" ");
      dados = dados.replace(aspSpl," \' ");
      dados = dados.replace("("," ( ");
      dados = dados.replace(")"," ) ");
      dados = dados.replace("\t"," ");
      dados = dados.replace("  "," ");
      dados = dados.replace("   "," ");
      dados = dados.replace("    "," ");
      dados = dados.replace("     "," ");
      dados = dados.replace("      "," ");
      dados = dados.replace("       "," ");
      dados = dados.replace("        "," ");
      dados = dados.replace("         "," ");
      dados = dados.replace("          "," ");
      dadosSeparados = dados.split(" ");
      for(int i =0; i<dadosSeparados.length; i++){
        System.out.println("palavra separada: " + dadosSeparados[i] + "\n");
      }


      for(int i = 1; i<10000;i++){
        //System.out.println("dados separados: " + dadosSeparados[indiceDados]);
        //System.out.println("valro do indiceDados: " + indiceDados);
        //System.out.println("Palavra da tabelaSimbolos: " + tabelaSimbolos[i][0]);
        //System.out.println("Palavra a ser reconhecida: " + dadosSeparados[indiceDados]);
        if(!(dadosSeparados[indiceDados].equals(""))){
	        if(dadosSeparados[indiceDados].equals(tabelaSimbolos[i][0])){
	          System.out.println("tipo de dado do " + dadosSeparados[indiceDados] + " EH "+ tabelaSimbolos[i][i]);
	          //se o professor quiser que adicione de novo eh soh tirar essa condicao
	          //if(!(palavrasReconhecidas.contains(dadosSeparados[indiceDados]))){
	            lexemaEtoken = "<  " + dadosSeparados[indiceDados] + " , " + tabelaSimbolos[i][i] + "  >";
	            palavrasReconhecidas.add(dadosSeparados[indiceDados]);

	            /*grava no arquivo a palavra encontrada*/
	            try {
	              //FileWriter grava = new FileWriter(arquivo, true);
	              //PrintWriter escreve = new PrintWriter(grava);
	              grava.write(lexemaEtoken + "\n");
	              resultadoFinal += lexemaEtoken + "\n";
	              //escreve.close();
	              //grava.close();
	            }catch (IOException ex) {
	              ex.printStackTrace();
	            }//fim catch
	          //}//fim if
	          indiceDados++;
	          try{
	            if(dadosSeparados[indiceDados] == null){
	                break;
	            }//fim if
	            else{
	              i = 1;
	            }//fim else
	          }catch(ArrayIndexOutOfBoundsException e){
	            break;
	          }//fim catch
	          //break;
	        }//fim if
	        else if(tabelaSimbolos[i][0] == null){
	          if(!(dadosSeparados[indiceDados].equals(""))){
	          	System.out.println("Palavra Inexistente: " + dadosSeparados[indiceDados]);
		          if(dadosSeparados[indiceDados].equals("/*") || dadosSeparados[indiceDados].equals("*/")){
		          	System.out.println("VERIFICANDO COMENTARIO");
		          	verificarIDCOMMENT(dadosSeparados[indiceDados]);
		          	System.out.println("valor do dado mal formado: " + dadosMalFormados);// caso eu queira avaliar o que esta depois do comentario mal formado eh so implementar o indiceDadosTemp igual fiz nos outros para voltar para o indice normal
		          	if(!(dadosMalFormados.equals(""))){
		          		try {
										grava.write(dadosMalFormados + "\n");
										resultadoFinal += dadosMalFormados + "\n";
				        	}catch (IOException ex) {
				          	ex.printStackTrace();
				        	}//fim catch
		          	}//fim if
		          	try{
			            if(dadosSeparados[indiceDados] == null){
			                break;
			            }//fim if
			            else{
			              i = 1;
			            }//fim else
			          }catch(ArrayIndexOutOfBoundsException e){
			            break;
			          }//fim catch
		          }//fim if
		          else{

			          if(verificarID(dadosSeparados[indiceDados].charAt(0))){//verifica se eh uma letra ou comentario ou numero
			            if(verificarIDvalido(dadosSeparados[indiceDados])){
			              tabelaSimbolos[i][0] = dadosSeparados[indiceDados].toUpperCase();
			              tabelaSimbolos[i][i] = "identificador";
			              System.out.println("Palavra adicionada como ID!");
			              lexemaEtoken = "<  " + dadosSeparados[indiceDados] + " , " + tabelaSimbolos[i][i] + "  >";
			              palavrasReconhecidas.add(dadosSeparados[indiceDados]);

			              /*grava no arquivo a palavra encontrada*/
			              try {
			                //FileWriter grava = new FileWriter(arquivo, true);
			                //PrintWriter escreve = new PrintWriter(grava);
			                if(crtlSimboloEsp == true){
			                  lexemaEtoken2 = "<  " + simbEspecialGeral + " , " + "simbolo_especial" + "  >";
			                  grava.write(lexemaEtoken  + "\n");
			                  grava.write(lexemaEtoken2 + "\n");
			                  resultadoFinal += lexemaEtoken  + "\n" + lexemaEtoken2 + "\n";
			                }else{
			                  grava.write(lexemaEtoken  + "\n");
			                  resultadoFinal += lexemaEtoken  + "\n";
			                }//fim else
			                //escreve.close();
			                //grava.close();
			              }catch (IOException ex) {
			                ex.printStackTrace();
			              }//fim catch
			              indiceDados++;
			              try{
			                if(dadosSeparados[indiceDados] == null){
			                  break;
			                }//fim if
			                else{
			                  i = 1;
			                }//fim else
			              }catch(ArrayIndexOutOfBoundsException e){
			                break;
			              }//fim catch
			            }//fim if
			            else{
			              System.out.println("Erro: identificador nao pode ter caracteres especiais, somente letras e numeros");
			              tabelaSimbolos[i][0] = dadosSeparados[indiceDados].toUpperCase();
			              tabelaSimbolos[i][i] = "identificador";
			              System.out.println("Palavra adicionada como ID!");
			              lexemaEtoken = "<  " + dadosSeparados[indiceDados] + " , " + tabelaSimbolos[i][i] + "  >" + " erro: identificador mal formado";
			              palavrasReconhecidas.add(dadosSeparados[indiceDados]);

			              /*grava no arquivo a palavra encontrada*/
			              try {
			                //FileWriter grava = new FileWriter(arquivo, true);
			                //PrintWriter escreve = new PrintWriter(grava);
			                if(crtlSimboloEsp == true){
			                  lexemaEtoken2 = "<  " + simbEspecialGeral + " , " + "simbolo_especial" + "  >";
			                  grava.write(lexemaEtoken  + "\n");
			                  grava.write(lexemaEtoken2 + "\n");
			                  resultadoFinal += lexemaEtoken  + "\n" + lexemaEtoken2 + "\n";
			                }else{
			                  grava.write(lexemaEtoken  + "\n");
			                  resultadoFinal += lexemaEtoken  + "\n";
			                }//fim else
			                //escreve.close();
			                //grava.close();
			              }catch (IOException ex) {
			                ex.printStackTrace();
			              }//fim catch
			              indiceDados++;
			              try{
			                if(dadosSeparados[indiceDados] == null){
			                  break;
			                }//fim if
			                else{
			                  i = 1;
			                }//fim else
			              }catch(ArrayIndexOutOfBoundsException e){
			                break;
			              }//fim catch
			              //break;
			            }//fim else
			          }//fim if
			          if(ignorar == true){
			          		if(!(dadosMalFormados.equals(""))){
				          		try {
												grava.write(dadosMalFormados + "\n");
												resultadoFinal += dadosMalFormados + "\n";
						        	}catch (IOException ex) {
						          	ex.printStackTrace();
						        	}//fim catch
				          	}//fim if
			          		Boolean crtlSubidaIndice = false; //verifica se entrou no numero real
			          		//System.out.println("ENTREI NO IGNORAR!!!!!!!!!!");
			          		if(crtlNumero == true){
			          			System.out.println("ENCONTREI O NUMERO: " + dadosSeparados[indiceDados]);
			          			try{
			          				String numeroRealOuInteiro = dadosSeparados[indiceDados];
				                if(dadosSeparados[indiceDados - 1].equals("+") || dadosSeparados[indiceDados - 1].equals("-") || dadosSeparados[indiceDados - 1].equals("*") || dadosSeparados[indiceDados - 1].equals("/") || dadosSeparados[indiceDados - 1].equals("mod") || dadosSeparados[indiceDados - 1].equals("=") || dadosSeparados[indiceDados - 1].equals(">=") || dadosSeparados[indiceDados - 1].equals(">") || dadosSeparados[indiceDados - 1].equals("<") || dadosSeparados[indiceDados - 1].equals("<=") || dadosSeparados[indiceDados - 1].equals("<>")|| dadosSeparados[indiceDados - 1].equals(":=")){
				                  //String numeroRealOuInteiro = dadosSeparados[indiceDados];
				                  String tipoDoNumero = "numero_inteiro";
				                  if(dadosSeparados[indiceDados+1].equals(",")){
				                  	crtlNumMalFormado = true;
			                  		System.out.println("Erro: Numero real mal formado!!!");
			                  		String auxTemp = dadosSeparados[indiceDados+1];
			                  		numeroRealOuInteiro += auxTemp;
			                  		lexemaEtoken3 = "<  " + numeroRealOuInteiro + " , " + tipoDoNumero + "  >" + "Erro: Numero real mal formado";
			        							grava.write(lexemaEtoken3  + "\n");
			        							resultadoFinal += lexemaEtoken3  + "\n";
				                  }//fim if
				                  else if(dadosSeparados[indiceDados+1].equals(".")){
				                  	//crtlSubidaIndice = true;
				                  	tipoDoNumero = "numero_real";
				                  	indiceDados += 2;//pula o ponto e vai pro proximo valor depois do ponto
				                  	numeroRealOuInteiro += ".";//adiciona o ponto ao numero 
				                  	//System.out.println("VALOR DO DADO: " + dadosSeparados[indiceDados]);
				                  	//System.out.println("VALOR DO DADO1: " + dadosSeparados[indiceDados].charAt(0));
				                  	String auxTemp = "" + dadosSeparados[indiceDados].charAt(0);
				                  	//System.out.println("VALOR DO AUX TEMP!!!!!! = " + auxTemp);
				                  	int contaNumeros = 0;
				                  	if(numeros.contains(auxTemp)){
				                  		while(numeros.contains(auxTemp)){
					                  		//System.out.println("ENTREI NO WHILE PARA VERIFICAR NUMEROS REAIS!!!!!!!!!!!!!!!");
					                  		System.out.println("valor do auxtemp: " + auxTemp);
						                  	numeroRealOuInteiro += auxTemp;
						                  	contaNumeros++;
						                  	if(contaNumeros >= dadosSeparados[indiceDados].length()){
						                  		break;
						                  	}//fim if
						                  	auxTemp = "" + dadosSeparados[indiceDados].charAt(contaNumeros);
						                  	if(!(numeros.contains(auxTemp))){
						                  		crtlNumMalFormado = true;
						                  		System.out.println("Erro: Numero real mal formado!!!");
						                  		numeroRealOuInteiro += auxTemp;
						                  		contaNumeros++;
						                  		if(contaNumeros >= dadosSeparados[indiceDados].length()){
							                  		lexemaEtoken3 = "<  " + numeroRealOuInteiro + " , " + tipoDoNumero + "  >" + "Erro: Numero real mal formado";
				        							grava.write(lexemaEtoken3  + "\n");
				        							resultadoFinal += lexemaEtoken3  + "\n";
							                  		break;
							                  	}else{
							                  		auxTemp = "" + dadosSeparados[indiceDados].charAt(contaNumeros);
							                  		numeroRealOuInteiro += auxTemp;
							                  		lexemaEtoken3 = "<  " + numeroRealOuInteiro + " , " + tipoDoNumero + "  >" + "Erro: Numero real mal formado";
				        							grava.write(lexemaEtoken3  + "\n");
				        							resultadoFinal += lexemaEtoken3  + "\n";
							                  	}//fim else
						                  	}
				                  		}//fim while
				                  	}else{
				                  		crtlNumMalFormado = true;
				                  		System.out.println("Erro: Numero real mal formado!!!");
				                  		lexemaEtoken3 = "<  " + numeroRealOuInteiro + " , " + tipoDoNumero + "  >" + "Erro: Numero real mal formado";
				        							grava.write(lexemaEtoken3  + "\n");
				        							resultadoFinal += lexemaEtoken3  + "\n";
				                  		//break;
				                  	}//fim else
				               
				                  }//fim if
				                  if(crtlNumMalFormado == false){
				                  	lexemaEtoken3 = "<  " + numeroRealOuInteiro + " , " + tipoDoNumero + "  >";
			        							grava.write(lexemaEtoken3  + "\n");
			        							resultadoFinal += lexemaEtoken3  + "\n";
				                  }//fim if
				                }//fim if
				                else{
				                  System.out.println("Erro: identificador nao pode iniciar com numeros: ");
				                  if(numeroRealOuInteiro.equals(":")){
				                  	lexemaEtoken = "<  " + numeroRealOuInteiro + " , " + "simbolo_especial" + "  >";
								            //palavrasReconhecidas.add(dadosSeparados[indiceDados]);

								            /*grava no arquivo a palavra encontrada*/
								            try {
								              //FileWriter grava = new FileWriter(arquivo, true);
								              //PrintWriter escreve = new PrintWriter(grava);
								              grava.write(lexemaEtoken + "\n");
								              resultadoFinal += lexemaEtoken + "\n";
								              //escreve.close();
								              //grava.close();
								            }catch (IOException ex) {
								              ex.printStackTrace();
								            }//fim catch
				                  }else{
				                  	lexemaEtoken3 = "<  " + numeroRealOuInteiro + " , " + "identificador" + "  >" + "Erro: identificador mal formado";
			        							grava.write(lexemaEtoken3  + "\n");
			        							resultadoFinal += lexemaEtoken3  + "\n";
				                  }//fim else
			              			//break;
				                }//fim else
			              	}catch(ArrayIndexOutOfBoundsException e){
			                	break;
			              	}//fim catch
			          		}//fim if crtl numero
			          		if(dadosMalFormados.equals("") && crtlNumero == true){
				          		indiceDados++;	
				          	}//fim if
			          		
			          		/*if(crtlSubidaIndice == false){
			          			indiceDados++;
			          		}//fim if*/
			              try{
			                if(dadosSeparados[indiceDados] == null){
			                    break;
			                }//fim if
			                else{
			                  i = 1;
			                }//fim else
			              }catch(ArrayIndexOutOfBoundsException e){
			                break;
			              }//fim catch
			          }//fim if ignorar true
			        }//fim else adicionar a tabela de simbolos
			      }//fim if verifica linha vazia
			      else{
			      	indiceDados++;
			      }//fim else
	          /*else{
	            //System.out.println("dados nao aceitos: " + dadosSeparados[indiceDados]);
	            //System.out.println("Erro: identificador nao pode iniciar com algo diferente de uma letra do alfabeto!");
	            indiceDados++;
	              try{
	                if(dadosSeparados[indiceDados] == null){
	                    break;
	                }//fim if
	                else{
	                  i = 1;
	                }//fim else
	              }catch(ArrayIndexOutOfBoundsException e){
	                break;
	              }//fim catch
	            //break;
	          }//fim else*/
	          try{
	            if(dadosSeparados[indiceDados] == null){
	                break;
	            }//fim if
	            else{
	              i = 1;
	            }//fim else
	          }catch(ArrayIndexOutOfBoundsException e){
	            break;
	          }//fim catch
	        }//fim else if
	      }//fim if verifica linha vazia
	      else{
	      	indiceDados++; //pula string vazia
	      }//fim else
      }//fim for

    	grava.close();

    	controlador.txtResultado.setText(resultadoFinal);

      /*for(String i : palavrasReconhecidas){
        System.out.println(i);
      }
      grava.close();*/

      //limpa o array
      for(int i = 1; i<10000;i++){
        tabelaSimbolos[i][0] = null;
        tabelaSimbolos[i][i] = null;
        if(tabelaSimbolos[i][i] == null){
          break;
        }//fim if
      }//fim for
      indiceDados = 0;
    }catch (IOException ex) {
      ex.printStackTrace();
    }//fim catch
    
    adicionarPalavrasReservadas();
    adicionarOperadoresRelacionais();
    adicionarOperadoresLogicos();
    adicionarOperadoresAritmeticos();
    adicionarSimbolosEspeciais();
    adicionarAtribuicao();
    adicionarFim();
  }//fim metodo recebeEntrada

  public Boolean verificarIDvalido(String id){
    Boolean crtl = true;
    crtlSimboloEsp = false;
    String strAux = "";
    for(int i =0;i<id.length();i++){
      strAux = "" + id.charAt(i);
      if(verificarID(id.charAt(i))){
      
      }else if(verificarIDNum(id.charAt(i))){

      }//fim else if
      else if(simbolosEspeciais.contains(strAux)){
        dadosSeparados[indiceDados] = dadosSeparados[indiceDados].replace(strAux,"");
        crtlSimboloEsp = true;
        simbEspecialGeral = strAux;
      }//fim else if
      else{
        crtl = false;
        break;
      }//fim else
    }//fim for
    return crtl;
  }//fim metodo verificarIDvalido

  public void verificarIDCOMMENT(String id){
    ignorar = false;
    crtlNumero = false;
    String idStr = id + "";
    //String aspasDuplas = "\"";
    //String aspasSimples = "\'";
    String inicioDeComentario = "/*";
    String fimDeComentario = "*/";
    dadosMalFormados = "";
    //int indiceDadosTemp = indiceDados;
    while(!(dadosSeparados[indiceDados].equals(fimDeComentario))){
      indiceDados++;
      //System.out.println("dentro do while do idcomment");
      try{
        if(dadosSeparados[indiceDados] == null){
        	//try {
	        	System.out.println("ERRO: COMENTARIO MAL FORMADO!");
            //lexemaEtoken = "< Comentario mal formado encontrado>";
						dadosMalFormados = "< Comentario mal formado encontrado>";
						//indiceDados++;
						break;
						//grava.write(lexemaEtoken + "\n");
	        /*}catch (IOException ex) {
	          ex.printStackTrace();
	        }//fim catch*/
            //break;
        }//fim if
      }catch(ArrayIndexOutOfBoundsException e){
      	System.out.println("ERRO: COMENTARIO MAL FORMADO!");
				dadosMalFormados = "< Comentario mal formado encontrado>";
				//indiceDados++;
        break;
      }//fim catch
    }//fim while
    indiceDados++;
  }//fim metodo verificarIDCOMMENT

  //Esse metodo verifica somente o primeiro caracter
  public Boolean verificarID(char id){
  	dadosMalFormados = "";
    ignorar = false;
    crtlNumero = false;
    String idStr = id + "";
    String aspasDuplas = "\"";
    String aspasSimples = "\'";
    String inicioDeComentario = "/*";
    String fimDeComentario = "*/";
    if(idStr.equals(aspasDuplas) || idStr.equals(aspasSimples) || idStr.equals(inicioDeComentario) || (numeros.contains(idStr)) || idStr.equals(fimDeComentario)){
      System.out.println("ENCONTREI O BAGUIOO KRLCT");
      ignorar = true;
      int indiceDadosTemp = indiceDados;
      if(idStr.equals(aspasDuplas)){
      	//indiceDadosTemp++;
      	String gravarString = "";
        indiceDados++;
        while(!(dadosSeparados[indiceDados].equals(aspasDuplas))){
        	gravarString += dadosSeparados[indiceDados];
          indiceDados++;
          try{
            if(dadosSeparados[indiceDados] == null){
                System.out.println("ERRO: STRING MAL FORMADA!");
                //try {
			            dadosMalFormados = "<ERRO: STRING MAL FORMADA ENCONTRADA>";
			            indiceDados = indiceDadosTemp;
			            break;
			            //lexemaEtoken = "< ERRO: STRING MAL FORMADA >";
									//grava.write(lexemaEtoken + "\n");
				        /*}catch (IOException ex) {
				          ex.printStackTrace();
				        }//fim catch*/
                //break;
            }
          }catch(ArrayIndexOutOfBoundsException e){
          	System.out.println("ERRO: STRING MAL FORMADA!");
            dadosMalFormados = "<ERRO: STRING MAL FORMADA ENCONTRADA>";
            indiceDados = indiceDadosTemp;
            break;
          }//fim catch
        }//fim while

        try {
					String lexemaEtoken3 = "<  " + "\"" + gravarString + "\"" + " , " + "string" + "  >";
					grava.write(lexemaEtoken3  + "\n");
					resultadoFinal += lexemaEtoken3  + "\n";
      	}catch (IOException ex) {
        	ex.printStackTrace();
      	}//fim catch

        System.out.println("A!!!!!!!! VALOR DO DADO !!!!!!!!!!: " + dadosSeparados[indiceDados]);
        indiceDados++;
        System.out.println("D!!!!!!!! VALOR DO DADO !!!!!!!!!!: " + dadosSeparados[indiceDados]);
        return false;
      }else if(idStr.equals(aspasSimples)){
      	indiceDados++;
      	//indiceDadosTemp++;
        while(!(dadosSeparados[indiceDados].equals(aspasSimples))){
          indiceDados++;
          try{
            if(dadosSeparados[indiceDados] == null){
                System.out.println("ERRO: STRING MAL FORMADA!");
                //try {
                	dadosMalFormados = "<ERRO: STRING MAL FORMADA ENCONTRADA>";
                	indiceDados = indiceDadosTemp;
                	break;
			            //lexemaEtoken = "< ERRO: STRING MAL FORMADA >";
									//grava.write(lexemaEtoken + "\n");
				        /*}catch (IOException ex) {
				          ex.printStackTrace();
				        }//fim catch*/
                //break;
            }//fim if
          }catch(ArrayIndexOutOfBoundsException e){
          	System.out.println("ERRO: STRING MAL FORMADA!");
            dadosMalFormados = "<ERRO: STRING MAL FORMADA ENCONTRADA>";
            indiceDados = indiceDadosTemp;
            break;
          }//fim catch
        }//fim while
        indiceDados++;
        return false;
      }else if(idStr.equals(inicioDeComentario)){
        while(!(dadosSeparados[indiceDados].equals(fimDeComentario))){
          indiceDados++;
          try{
            if(dadosSeparados[indiceDados] == null){
                System.out.println("ERRO: COMENTARIO MAL FORMADO!");
                //try {
			            dadosMalFormados = "< Comentario mal formado encontrado>";
									//grava.write(lexemaEtoken + "\n");
				        /*}catch (IOException ex) {
				          ex.printStackTrace();
				        }//fim catch*/
                //break;
            }//fim if
          }catch(ArrayIndexOutOfBoundsException e){
          	System.out.println("ERRO: COMENTARIO MAL FORMADO!");
          	dadosMalFormados = "< Comentario mal formado encontrado>";
            break;
          }//fim catch
        }//fim while
        return false;
      }//fim else if
      crtlNumero = true;
      return false;
    }//fim if
    idStr = idStr.toUpperCase();
    Boolean res;
    if(letras.contains(idStr)){
      res = true;
      return res;
    }//fim if
    return false;
  }//fim metodo verificarID

  public Boolean verificarIDNum(char id){
    String idStr = id + "";
    Boolean res = numeros.contains(idStr);
    return res;
  }//fim metodo verificarID

  public void adicionarNumeros(){
    numeros.add("0");
    numeros.add("1");
    numeros.add("2");
    numeros.add("3");
    numeros.add("4");
    numeros.add("5");
    numeros.add("6");
    numeros.add("7");
    numeros.add("8");
    numeros.add("9");
  }

  public void adicionarAlfabeto(){
    letras.add("A");
    letras.add("B");
    letras.add("C");
    letras.add("D");
    letras.add("E");
    letras.add("F");
    letras.add("G");
    letras.add("H");
    letras.add("I");
    letras.add("J");
    letras.add("K");
    letras.add("L");
    letras.add("M");
    letras.add("N");
    letras.add("O");
    letras.add("P");
    letras.add("Q");
    letras.add("R");
    letras.add("S");
    letras.add("T");
    letras.add("U");
    letras.add("V");
    letras.add("W");
    letras.add("X");
    letras.add("Y");
    letras.add("Z");
  }//fim metodo adicionar

  	//adiciona as palavras reservadas na tabela
    public void adicionarPalavrasReservadas(){
        //tabelaSimbolos[][0] = "";
        //tabelaSimbolos[][] = "palavra_reservada";
        tabelaSimbolos[1][0] = "WHILE";
        tabelaSimbolos[2][0] = "DO";
        tabelaSimbolos[3][0] = "IF";
        tabelaSimbolos[4][0] = "THEN";
        tabelaSimbolos[5][0] = "ELSE";
        tabelaSimbolos[24][0] = "INTEGER";
        tabelaSimbolos[25][0] = "READ";
        tabelaSimbolos[26][0] = "WRITE";
        tabelaSimbolos[27][0] = "READLN";
        tabelaSimbolos[28][0] = "WRITELN";
        tabelaSimbolos[29][0] = "PROGRAM";
        tabelaSimbolos[30][0] = "BEGIN";
        tabelaSimbolos[31][0] = "END";
        tabelaSimbolos[32][0] = "BOOLEAN";
        tabelaSimbolos[33][0] = "STR";
        tabelaSimbolos[34][0] = "VAR";
        tabelaSimbolos[35][0] = "CONST";
        tabelaSimbolos[37][0] = "TRUE";
        tabelaSimbolos[38][0] = "FALSE";






        
        /*******************************************/

        tabelaSimbolos[1][1] = "palavra_reservada";
        tabelaSimbolos[2][2] = "palavra_reservada";
        tabelaSimbolos[3][3] = "palavra_reservada";
        tabelaSimbolos[4][4] = "palavra_reservada";
        tabelaSimbolos[5][5] = "palavra_reservada";
        tabelaSimbolos[24][24] = "INTEGER";
        tabelaSimbolos[25][25] = "palavra_reservada";
        tabelaSimbolos[26][26] = "palavra_reservada";
        tabelaSimbolos[27][27] = "palavra_reservada";
        tabelaSimbolos[28][28] = "palavra_reservada";
        tabelaSimbolos[29][29] = "palavra_reservada";
        tabelaSimbolos[30][30] = "palavra_reservada";
        tabelaSimbolos[31][31] = "palavra_reservada";
        tabelaSimbolos[32][32] = "BOOLEAN";
        tabelaSimbolos[33][33] = "STR";
        tabelaSimbolos[34][34] = "palavra_reservada";
        tabelaSimbolos[35][35] = "palavra_reservada";
        tabelaSimbolos[37][37] = "operador_logico";
        tabelaSimbolos[38][38] = "operador_logico";


    }//fim metodo adicionarPalavrasReservadas

    //adiciona os operadores relacionais na tabela de simbolos
    public void adicionarOperadoresRelacionais(){
      tabelaSimbolos[6][0] = "=";
      tabelaSimbolos[7][0] = ">=";
      tabelaSimbolos[8][0] = "<=";
      tabelaSimbolos[9][0] = ">";
      tabelaSimbolos[10][0] = "<";
      tabelaSimbolos[11][0] = "<>";      
      /********************************/

      tabelaSimbolos[6][6] = "operador_relacional";
      tabelaSimbolos[7][7] = "operador_relacional";
      tabelaSimbolos[8][8] = "operador_relacional";
      tabelaSimbolos[9][9] = "operador_relacional";
      tabelaSimbolos[10][10] = "operador_relacional";
      tabelaSimbolos[11][11] = "operador_relacional";
    }//fim metodo adicionarOperadoresRelacionais

    public void adicionarOperadoresLogicos(){
      tabelaSimbolos[12][0] = "TRUE";
      tabelaSimbolos[13][0] = "FALSE";

      /****************************/

      tabelaSimbolos[12][12] = "operador_logico";
      tabelaSimbolos[13][13] = "operador_logico";
    }//fim metodo adicionarOperadoresLogicos()

    public void adicionarOperadoresAritmeticos(){
      tabelaSimbolos[14][0] = "+";
      tabelaSimbolos[15][0] = "-";
      tabelaSimbolos[16][0] = "*";
      tabelaSimbolos[17][0] = "/";

      /**********************************/

      tabelaSimbolos[14][14] = "operador_aritmetico";
      tabelaSimbolos[15][15] = "operador_aritmetico";
      tabelaSimbolos[16][16] = "operador_aritmetico";
      tabelaSimbolos[17][17] = "operador_aritmetico";
    }//fim metodo adicionarOperadoresAritmeticos

    //adiciona os simbolos especiais e/ou delimitadores na tabela
    public void adicionarSimbolosEspeciais(){
      simbolosEspeciais.add(",");
      simbolosEspeciais.add(":");
      simbolosEspeciais.add(";");
      simbolosEspeciais.add(".");
      simbolosEspeciais.add("(");
      simbolosEspeciais.add(")");

      tabelaSimbolos[18][0] = ",";
      tabelaSimbolos[19][0] = ":";
      tabelaSimbolos[20][0] = ";";
      //tabelaSimbolos[36][0] = ".";
      tabelaSimbolos[21][0] = "(";
      tabelaSimbolos[22][0] = ")";

      /*******************************/

      tabelaSimbolos[18][18] = "simbolo_especial";
      tabelaSimbolos[19][19] = "simbolo_especial";
      tabelaSimbolos[20][20] = "simbolo_especial";
      tabelaSimbolos[21][21] = "simbolo_especial";
      tabelaSimbolos[22][22] = "simbolo_especial";
     // tabelaSimbolos[36][36] = "simbolo_especial";
    }//fim metodo adicionarSimbolosEspeciais

    //adiciona o operador de atribuicao na tabela
    public void adicionarAtribuicao(){
      tabelaSimbolos[23][0] = ":=";
      /*******************************/
      tabelaSimbolos[23][23] = "Atribuicao";
    }//fim metodo adicionarAtribuicao

    //adiciona o operador de fim de programa na tabela
    public void adicionarFim(){
      tabelaSimbolos[36][0] = ".";
      
      tabelaSimbolos[36][36] = "FIM";
    }//fim metodo adicionarFim

    //recebe o controlador da tela de interface
		public void setControl(Controlador c){
			controlador = c;
		}//fim metodo setControl

}//fim classe AnalisadorLexico


// coisas a se considerar: 
// 1: na nossa linguagem os operadores aritmeticos terao que estar separados dos numeros
// ex: 1+2(vai da erro) o certo eh: 1 + 2
// adicionar simbolos nos num reais